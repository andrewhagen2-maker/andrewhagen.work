"""
dungeon.py — Dungeon layout and room management for The Dark Keep.

23-room layout (21 main + 2 secret):

  (0,0)start ──E── (1,0)combat_a ──E── (2,0)treasure_a ──E── (3,0)coin_a ~~BOMB~~E~~ (4,0)secret_vault
                        │                     │                      │
                        S                     S                      S
                        │                     │                      │
                    (1,1)shop ──E── (2,1)combat_b ──E── (3,1)combat_c ~~BOMB~~E~~ (4,1)secret_cache
                                         │
                                         S
                                         │
                                    (2,2)safe_a ──E── (3,2)treasure_b
                                         │
                                         S
                                         │
                                    (2,3)combat_hard
                                         │
                                         S
                                         │
                                    (2,4)dragon_room ──E── (3,4)dragon_vault  ← mini-boss
                                         │
                               S  [LOCKED until dragon falls; E also locked]
                                         │
                                    (2,5)bat_cave  ← stationary bats in circle
                                         │
                                    (2,6)rest_room
                                         │
                                    (2,7)zombie_crypt
                                         │
                                    (2,8)shop_2
                                         │
                                    (2,9)crypt_passage
                                         │
                                    (2,10)treasure_c
                                         │
                                    (2,11)dark_corridor
                                         │
                                    (2,12)kings_antechamber
                                         │
                                    (2,13)skeleton_king  ← final boss

  ~~BOMB~~  =  bomb-breakable wall (blow it up to reveal the secret passage)
"""

import copy
from room import Room

# ── Dungeon map definition ────────────────────────────────────────────────────
#
#  Each entry:
#    title        : name shown on screen when the player enters
#    type         : 'safe' | 'combat' | 'treasure' | 'coin' | 'shop'
#                   | 'mini_boss' | 'boss'
#    doors        : { direction: connected_room_id }  (N / S / E / W)
#    locked_doors : subset of doors that start locked (optional)

DUNGEON_MAP = {

    # ── safe / non-combat rooms (no enemies) ──────────────────────────────────

    'start': {
        'title':        'The Dark Keep',
        'type':         'safe',
        'doors':        {'E': 'combat_a', 'S': 'quiz_room'},
        'mystery_locked_doors': {'S'},
        'grid_pos':     (0, 0),
        'enemy_spawns': {},
    },

    'quiz_room': {
        'title':        '??????',
        'type':         'quiz',
        'doors':        {'N': 'start'},
        'grid_pos':     (0, 1),
        'enemy_spawns': {},
    },

    'treasure_a': {
        'title':        'The Armory',
        'type':         'treasure',
        'doors':        {'W': 'combat_a', 'E': 'coin_a', 'S': 'combat_b'},
        'grid_pos':     (2, 0),
        'enemy_spawns': {},
        'weapon_pickup': 'spear',      # first upgrade weapon found here
    },

    'coin_a': {
        'title':        'The Treasury',
        'type':         'coin',
        'doors':        {'W': 'treasure_a', 'S': 'combat_c', 'E': 'secret_vault'},
        'bomb_locked_doors': {'E'},
        'grid_pos':     (3, 0),
        'enemy_spawns': {},
        'coin_count':   8,
    },

    'shop': {
        'title':        'The Wandering Merchant',
        'type':         'shop',
        'doors':        {'N': 'combat_a', 'E': 'combat_b'},
        'grid_pos':     (1, 1),
        'enemy_spawns': {},
    },

    'safe_a': {
        'title':        'Ancient Shrine',
        'type':         'safe',
        'doors':        {'N': 'combat_b', 'S': 'combat_hard', 'E': 'treasure_b'},
        'grid_pos':     (2, 2),
        'enemy_spawns': {},
        'weapon_pickup': 'bow',       # mid-game ranged weapon; shrine blessing
    },

    'treasure_b': {
        'title':        'Forbidden Vault',
        'type':         'treasure',
        'doors':        {'W': 'safe_a'},
        'grid_pos':     (3, 2),
        'enemy_spawns': {},
        'weapon_pickup': 'laser_gun',  # powerful late-game weapon
    },

    # ── combat rooms (skeletons + new enemy types) ─────────────────────────────

    'combat_a': {
        'title':        'Guard Chamber',
        'type':         'combat',
        'doors':        {'W': 'start', 'E': 'treasure_a', 'S': 'shop'},
        'grid_pos':     (1, 0),
        'enemy_spawns': {'skeleton': 3},
    },

    'combat_b': {
        'title':        'The Barracks',
        'type':         'combat',
        'doors':        {'W': 'shop', 'N': 'treasure_a', 'S': 'safe_a', 'E': 'combat_c'},
        'grid_pos':     (2, 1),
        'enemy_spawns': {'skeleton': 2, 'zombie': 1},
    },

    'combat_c': {
        'title':        'The Watch Tower',
        'type':         'combat',
        'doors':        {'N': 'coin_a', 'W': 'combat_b', 'E': 'secret_cache'},
        'bomb_locked_doors': {'E'},
        'grid_pos':     (3, 1),
        'enemy_spawns': {'skeleton': 2, 'bat': 2},
    },

    'combat_hard': {
        'title':        'Hall of Bones',
        'type':         'combat',
        'doors':        {'N': 'safe_a', 'S': 'dragon_room'},
        'grid_pos':     (2, 3),
        'enemy_spawns': {'skeleton': 2, 'zombie': 2, 'bat': 2},
        'weapon_pickup': 'two_handed_sword',  # powerful sword; reward before dragon
        'coin_count':    5,                   # bonus coins for a tough room
        'chest_count':   1,
        'heart_count':   1,                   # one guaranteed heart before the dragon
    },

    # ── boss rooms (enemies added in Phase 6) ─────────────────────────────────

    'dragon_room': {
        'title':        "The Dragon's Lair",
        'type':         'mini_boss',
        'doors':        {'N': 'combat_hard', 'S': 'bat_cave', 'E': 'dragon_vault'},
        'locked_doors': {'S', 'E'},
        'grid_pos':     (2, 4),
        'enemy_spawns': {'dragon': 1},
    },

    # ── rooms between dragon and Skeleton King ─────────────────────────────────

    'dragon_vault': {
        'title':        "The Dragon's Hoard",
        'type':         'treasure',
        'doors':        {'W': 'dragon_room'},
        'grid_pos':     (3, 4),
        'enemy_spawns': {},
        'weapon_pickup': 'laser_sword',   # ultimate reward for slaying the dragon
        'coin_count':    10,              # bonus gold from the dragon's hoard
    },

    'bat_cave': {
        'title':            'The Bat Cave',
        'type':             'combat',
        'doors':            {'N': 'dragon_room', 'S': 'rest_room'},
        'grid_pos':         (2, 5),
        'enemy_spawns':     {},
        'bat_circle_count': 8,            # 8 stationary bats in a circle
        'heart_container_pickup': True,   # glowing heart container at centre
    },

    'rest_room': {
        'title':        'Forgotten Alcove',
        'type':         'safe',
        'doors':        {'N': 'bat_cave', 'S': 'zombie_crypt'},
        'grid_pos':     (2, 6),
        'enemy_spawns': {},
        'heart_count':  3,               # 3 static hearts scattered on the floor
    },

    'zombie_crypt': {
        'title':        'The Zombie Crypt',
        'type':         'combat',
        'doors':        {'N': 'rest_room', 'S': 'shop_2'},
        'grid_pos':     (2, 7),
        'enemy_spawns': {'zombie': 6},
    },

    'shop_2': {
        'title':        'The Wandering Merchant',
        'type':         'shop',
        'doors':        {'N': 'zombie_crypt', 'S': 'crypt_passage'},
        'grid_pos':     (2, 8),
        'enemy_spawns': {},
    },

    'crypt_passage': {
        'title':        'The Crypt Passage',
        'type':         'combat',
        'doors':        {'N': 'shop_2', 'S': 'treasure_c'},
        'grid_pos':     (2, 9),
        'enemy_spawns': {'skeleton': 2, 'skeleton_archer': 2, 'zombie': 2},
        'weapon_pickup': 'mega_bow',   # explosive bow — reward for clearing a tough room
    },

    'treasure_c': {
        'title':        'The Bone Vault',
        'type':         'coin',
        'doors':        {'N': 'crypt_passage', 'S': 'dark_corridor'},
        'grid_pos':     (2, 10),
        'enemy_spawns': {},
        'coin_count':   10,
        'chest_count':  2,
    },

    'dark_corridor': {
        'title':        'The Dark Corridor',
        'type':         'combat',
        'doors':        {'N': 'treasure_c', 'S': 'kings_antechamber'},
        'grid_pos':     (2, 11),
        'enemy_spawns': {'skeleton': 1, 'skeleton_archer': 2, 'bat': 2, 'skeleton_knight': 1},
        'weapon_pickup': 'storm_blade',   # electric arc weapon — near-final room upgrade
    },

    'kings_antechamber': {
        'title':        "The King's Antechamber",
        'type':         'combat',
        'doors':        {'N': 'dark_corridor', 'S': 'skeleton_king'},
        'grid_pos':     (2, 12),
        'enemy_spawns': {'skeleton': 2, 'skeleton_archer': 2, 'skeleton_knight': 2},
    },

    # ── secret rooms (bomb-breakable walls) ───────────────────────────────────

    'secret_vault': {
        'title':        'Hidden Vault',
        'type':         'secret',
        'doors':        {'W': 'coin_a'},
        'grid_pos':     (4, 0),
        'enemy_spawns': {},
        'coin_count':   20,              # jackpot — lots of coins
    },

    'secret_cache': {
        'title':        'The Armory Cache',
        'type':         'secret',
        'doors':        {'W': 'combat_c'},
        'grid_pos':     (4, 1),
        'enemy_spawns': {},
        'bomb_pickup':  True,            # bag of 5 bombs waiting on the floor
    },

    # ── final boss ─────────────────────────────────────────────────────────────

    'skeleton_king': {
        'title':        'Throne of the Skeleton King',
        'type':         'boss',
        'doors':        {'N': 'kings_antechamber'},
        'grid_pos':     (2, 13),
        'enemy_spawns': {'skeleton_king': 1},
    },
}

# Opposite direction lookup
OPPOSITE = {'N': 'S', 'S': 'N', 'W': 'E', 'E': 'W'}


# ── Dungeon class ─────────────────────────────────────────────────────────────

class Dungeon:
    """
    Owns all Room instances and tracks the current room.
    Call dungeon.go(direction) to move between rooms.
    """

    def __init__(self):
        self.rooms = {}
        # Rooms where the center south torch should be suppressed (overlaps a door)
        _no_center_south_torch_rooms = {'start', 'dragon_room'}

        # Work from a deep copy of DUNGEON_MAP so unlock mutations (discard on
        # locked/mystery/bomb door sets) never bleed across restarts.
        self._map = copy.deepcopy(DUNGEON_MAP)

        for room_id, data in self._map.items():
            door_dirs             = set(data['doors'].keys())
            locked_doors          = set(data.get('locked_doors', []))
            mystery_locked_doors  = set(data.get('mystery_locked_doors', []))
            bomb_locked_doors     = set(data.get('bomb_locked_doors', []))
            self.rooms[room_id] = Room(
                doors                    = door_dirs,
                locked_doors             = locked_doors | bomb_locked_doors,
                mystery_locked_doors     = mystery_locked_doors,
                bomb_locked_doors        = bomb_locked_doors,
                room_type                = data['type'],
                enemy_spawns             = data.get('enemy_spawns', {}),
                weapon_pickup            = data.get('weapon_pickup', None),
                coin_count               = data.get('coin_count', 0),
                heart_container_pickup   = data.get('heart_container_pickup', False),
                heart_count              = data.get('heart_count', 0),
                chest_count              = data.get('chest_count', 0),
                bomb_pickup              = data.get('bomb_pickup', False),
                no_center_south_torch    = room_id in _no_center_south_torch_rooms,
                bat_circle_count         = data.get('bat_circle_count', 0),
            )
        self.current_id = 'start'

    # ── properties ───────────────────────────────────────────────────────────

    @property
    def current_room(self):
        return self.rooms[self.current_id]

    @property
    def current_title(self):
        return self._map[self.current_id]['title']

    @property
    def current_type(self):
        return self._map[self.current_id]['type']

    # ── navigation ───────────────────────────────────────────────────────────

    def can_go(self, direction):
        """Return True if the exit exists and is unlocked."""
        data   = self._map[self.current_id]
        locked = data.get('locked_doors', set())
        return direction in data['doors'] and direction not in locked

    def go(self, direction):
        """
        Move to the connected room in the given direction.
        Returns the entry direction in the new room, or None if blocked.
        """
        if not self.can_go(direction):
            return None
        next_id = self._map[self.current_id]['doors'][direction]
        self.current_id = next_id
        return OPPOSITE[direction]

    def unlock_door(self, room_id, direction):
        """Unlock a door (called when a boss is defeated)."""
        self.rooms[room_id].unlock_door(direction)
        data = self._map[room_id]
        if 'locked_doors' in data:
            data['locked_doors'].discard(direction)

    def unlock_mystery_door(self, room_id, direction):
        """Unlock a mystery-key-locked door (called when player uses a key)."""
        self.rooms[room_id].unlock_mystery_door(direction)
        data = self._map[room_id]
        if 'mystery_locked_doors' in data:
            data['mystery_locked_doors'].discard(direction)

    def unlock_bomb_door(self, room_id, direction):
        """Reveal a bomb-breakable secret passage in both this room and the neighbour."""
        room = self.rooms[room_id]
        room.unlock_bomb_door(direction)
        data = self._map[room_id]
        if 'bomb_locked_doors' in data:
            data['bomb_locked_doors'].discard(direction)
        # Also open the opposite door in the secret room itself
        neighbour_id = self._map[room_id]['doors'].get(direction)
        if neighbour_id and neighbour_id in self.rooms:
            opp = OPPOSITE[direction]
            self.rooms[neighbour_id].unlock_door(opp)   # secret room's W door
