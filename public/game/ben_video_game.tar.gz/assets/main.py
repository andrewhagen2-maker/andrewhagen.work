"""
main.py — Entry point for The Dark Keep.

Desktop run:
    python main.py

Web (pygbag):
    pygbag .
    then open http://localhost:8000

REQUIREMENTS (one-time install):
    pip install pygame pygbag
"""

import asyncio
import os
import sys


def ensure_sprites():
    """Generate sprites if any are missing. Skipped in browser (wasm) builds."""
    # In pygbag/wasm there is no writable filesystem, so we skip generation
    # and rely on the pre-generated PNGs bundled with the build.
    if sys.platform == 'emscripten':
        return

    base = os.path.dirname(__file__)
    markers = [
        os.path.join(base, 'sprites', 'tiles',   'floor.png'),
        os.path.join(base, 'sprites', 'enemies', 'ghost.png'),
    ]
    if any(not os.path.exists(m) for m in markers):
        print('Generating pixel art sprites...')
        from generate_sprites import generate_all
        generate_all()
        print()


async def main():
    import pygame
    pygame.init()

    ensure_sprites()

    from game import Game
    game = Game()
    await game.run()

    pygame.quit()


asyncio.run(main())
