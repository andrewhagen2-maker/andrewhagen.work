"""
enemy.py — Enemy classes for The Dark Keep.

Phase 3:
  - Enemy           : base class
  - Skeleton        : basic melee enemy

Phase 3 extras:
  - Zombie          : slow, high-HP tanker
  - Bat             : ranged; keeps distance, fires fireballs

Phase 8:
  - SkeletonArcher  : ranged skeleton; backs away, fires bone arrows

Phase 6:
  - Dragon          : mini-boss — slow, fires a 3-shot fire-breath spread
  - SkeletonKing    : final boss — two-phase fight; phase 2 summons skeletons
"""

import pygame
import os
import math
import random

from settings import (
    TILE_SIZE,
    ROOM_OFFSET_X, ROOM_OFFSET_Y,
    ROOM_COLS, ROOM_ROWS,
)

ENEMY_DIR = os.path.join(os.path.dirname(__file__), 'sprites', 'enemies')
BOSS_DIR  = os.path.join(os.path.dirname(__file__), 'sprites', 'bosses')


# ── Base Enemy ────────────────────────────────────────────────────────────────

class Enemy(pygame.sprite.Sprite):
    """
    Generic enemy.

    Sub-classes set hp, speed, contact_damage, sprite_name
    (and optionally sprite_dir) via super().__init__(...).

    update() returns:
      None           — nothing fired
      EnemyProjectile — single projectile (Bat fireball)
      [EnemyProjectile, …] — list of projectiles (Dragon breath)
    """

    SPRITE_SIZE = 32      # display size in pixels

    def __init__(self, x, y, hp, speed, contact_damage, sprite_name,
                 sprite_dir=None):
        super().__init__()

        self.max_hp         = hp
        self.hp             = hp
        self.speed          = speed
        self.contact_damage = contact_damage

        self.coin_drop    = random.randint(1, 3)
        self.inv_frames   = 0
        self.inv_duration = 12
        self.flash_frames = 0

        # Boss flag & type tag (set by sub-classes)
        self.is_boss   = False
        self.boss_type = None

        # Pending enemy spawns (used by SkeletonKing phase 2)
        self.pending_spawns = []

        # ── sprite ────────────────────────────────────────────────────────────
        sdir = sprite_dir or ENEMY_DIR
        path = os.path.join(sdir, sprite_name)
        if os.path.exists(path):
            raw        = pygame.image.load(path).convert_alpha()
            self.image = pygame.transform.scale(raw, (self.SPRITE_SIZE, self.SPRITE_SIZE))
        else:
            self.image = pygame.Surface((self.SPRITE_SIZE, self.SPRITE_SIZE),
                                        pygame.SRCALPHA)
            self.image.fill((220, 50, 50, 220))

        self.rect   = self.image.get_rect(center=(x, y))
        self.hitbox = pygame.Rect(0, 0, TILE_SIZE - 14, TILE_SIZE - 14)
        self.hitbox.center = self.rect.center

        self._fx = float(x)
        self._fy = float(y)

    # ── combat ────────────────────────────────────────────────────────────────

    def take_hit(self, damage):
        if self.inv_frames > 0:
            return False
        self.hp          -= damage
        self.inv_frames   = self.inv_duration
        self.flash_frames = 10
        return True

    def try_damage_player(self, player):
        if self.hitbox.colliderect(player.hitbox):
            player.take_damage(self.contact_damage)

    @property
    def is_dead(self):
        return self.hp <= 0

    # ── update ────────────────────────────────────────────────────────────────

    def update(self, player, walls):
        self._chase(player, walls)
        if self.inv_frames   > 0: self.inv_frames   -= 1
        if self.flash_frames > 0: self.flash_frames -= 1
        self.hitbox.center = (int(self._fx), int(self._fy))
        self.rect.center   = self.hitbox.center
        return None

    def _chase(self, player, walls):
        px, py = player.hitbox.center
        dx = px - self._fx
        dy = py - self._fy
        dist = math.hypot(dx, dy)
        if dist < 1:
            return

        vx = dx / dist * self.speed
        vy = dy / dist * self.speed

        self._fx += vx
        self.hitbox.centerx = int(self._fx)
        for wall in walls:
            if self.hitbox.colliderect(wall):
                if vx > 0: self.hitbox.right = wall.left
                else:      self.hitbox.left  = wall.right
                self._fx = float(self.hitbox.centerx)

        self._fy += vy
        self.hitbox.centery = int(self._fy)
        for wall in walls:
            if self.hitbox.colliderect(wall):
                if vy > 0: self.hitbox.bottom = wall.top
                else:      self.hitbox.top    = wall.bottom
                self._fy = float(self.hitbox.centery)

    # ── drawing ───────────────────────────────────────────────────────────────

    def draw(self, surface):
        if self.flash_frames > 0 and self.flash_frames % 2 == 0:
            flash = self.image.copy()
            flash.fill((200, 200, 200), special_flags=pygame.BLEND_RGB_ADD)
            surface.blit(flash, self.rect)
        else:
            surface.blit(self.image, self.rect)

        if self.hp < self.max_hp:
            self._draw_hp_bar(surface)

    def _draw_hp_bar(self, surface):
        w    = self.SPRITE_SIZE
        x    = self.rect.left
        y    = self.rect.top - 7
        pygame.draw.rect(surface, (70, 15, 15),  (x, y, w,                        4))
        fill = max(1, int(w * self.hp / self.max_hp))
        pygame.draw.rect(surface, (220, 50, 50), (x, y, fill,                     4))
        pygame.draw.rect(surface, (255, 90, 90), (x, y, fill,                     1))


# ── Skeleton ──────────────────────────────────────────────────────────────────

class Skeleton(Enemy):
    def __init__(self, x, y):
        super().__init__(x=x, y=y, hp=3, speed=1.2, contact_damage=1,
                         sprite_name='skeleton.png')


# ── Zombie ────────────────────────────────────────────────────────────────────

class Zombie(Enemy):
    def __init__(self, x, y):
        super().__init__(x=x, y=y, hp=12, speed=0.6, contact_damage=1,
                         sprite_name='zombie.png')
        self.coin_drop = random.randint(3, 6)


# ── Bat ───────────────────────────────────────────────────────────────────────

class Bat(Enemy):
    FIRE_INTERVAL  = 120
    PREFERRED_DIST = 5 * TILE_SIZE

    def __init__(self, x, y, stationary=False):
        super().__init__(x=x, y=y, hp=1, speed=0.8, contact_damage=1,
                         sprite_name='bat.png')
        self.fire_timer = random.randint(30, self.FIRE_INTERVAL)
        self.coin_drop  = 1
        self._stationary = stationary

    def update(self, player, walls):
        if not self._stationary:
            self._keep_distance(player, walls)
        if self.inv_frames   > 0: self.inv_frames   -= 1
        if self.flash_frames > 0: self.flash_frames -= 1
        self.hitbox.center = (int(self._fx), int(self._fy))
        self.rect.center   = self.hitbox.center
        self.fire_timer -= 1
        if self.fire_timer <= 0:
            self.fire_timer = self.FIRE_INTERVAL
            return self._make_fireball(player)
        return None

    def _keep_distance(self, player, walls):
        px, py = player.hitbox.center
        dx = px - self._fx
        dy = py - self._fy
        dist = math.hypot(dx, dy)
        if dist < 1:
            return
        if dist < self.PREFERRED_DIST:
            vx = -(dx / dist) * self.speed
            vy = -(dy / dist) * self.speed
        else:
            vx = (dx / dist) * self.speed * 0.4
            vy = (dy / dist) * self.speed * 0.4
        self._fx += vx
        self.hitbox.centerx = int(self._fx)
        for wall in walls:
            if self.hitbox.colliderect(wall):
                if vx > 0: self.hitbox.right  = wall.left
                else:      self.hitbox.left   = wall.right
                self._fx = float(self.hitbox.centerx)
        self._fy += vy
        self.hitbox.centery = int(self._fy)
        for wall in walls:
            if self.hitbox.colliderect(wall):
                if vy > 0: self.hitbox.bottom = wall.top
                else:      self.hitbox.top    = wall.bottom
                self._fy = float(self.hitbox.centery)

    def _make_fireball(self, player):
        from weapons import EnemyProjectile
        px, py = player.hitbox.center
        return EnemyProjectile(int(self._fx), int(self._fy), px, py, damage=1)


# ── Skeleton Archer ───────────────────────────────────────────────────────────

class SkeletonArcher(Enemy):
    """
    Ranged skeleton.  Tries to maintain a comfortable distance from the
    player and fires bone-arrow projectiles.  Actively backs away when the
    player closes in.

    Attributes
    ----------
    hp            : 4   (slightly more than a basic Skeleton)
    speed         : 1.4 (nimble, retreats quickly)
    contact_damage: 1
    PREFERRED_DIST: 5 tiles (keeps range)
    FIRE_INTERVAL : 90 frames (~1.5 s)
    """

    FIRE_INTERVAL  = 90
    PREFERRED_DIST = 5 * TILE_SIZE

    def __init__(self, x, y):
        super().__init__(x=x, y=y, hp=4, speed=1.4, contact_damage=1,
                         sprite_name='skeleton_archer.png')
        self.fire_timer = random.randint(30, self.FIRE_INTERVAL)
        self.coin_drop  = random.randint(2, 4)

    def update(self, player, walls):
        self._keep_distance(player, walls)
        if self.inv_frames   > 0: self.inv_frames   -= 1
        if self.flash_frames > 0: self.flash_frames -= 1
        self.hitbox.center = (int(self._fx), int(self._fy))
        self.rect.center   = self.hitbox.center

        self.fire_timer -= 1
        if self.fire_timer <= 0:
            self.fire_timer = self.FIRE_INTERVAL
            return self._shoot_arrow(player)
        return None

    def _keep_distance(self, player, walls):
        """Strafe/back up when too close; drift toward range when too far."""
        px, py = player.hitbox.center
        dx = px - self._fx
        dy = py - self._fy
        dist = math.hypot(dx, dy)
        if dist < 1:
            return

        if dist < self.PREFERRED_DIST:
            # Back away
            vx = -(dx / dist) * self.speed
            vy = -(dy / dist) * self.speed
        else:
            # Drift in slowly to stay in range
            vx = (dx / dist) * self.speed * 0.35
            vy = (dy / dist) * self.speed * 0.35

        self._fx += vx
        self.hitbox.centerx = int(self._fx)
        for wall in walls:
            if self.hitbox.colliderect(wall):
                if vx > 0: self.hitbox.right  = wall.left
                else:      self.hitbox.left   = wall.right
                self._fx = float(self.hitbox.centerx)

        self._fy += vy
        self.hitbox.centery = int(self._fy)
        for wall in walls:
            if self.hitbox.colliderect(wall):
                if vy > 0: self.hitbox.bottom = wall.top
                else:      self.hitbox.top    = wall.bottom
                self._fy = float(self.hitbox.centery)

    def _shoot_arrow(self, player):
        from weapons import EnemyProjectile
        px, py = player.hitbox.center
        arrow = EnemyProjectile(int(self._fx), int(self._fy), px, py, damage=1)
        # Bone arrows are a little faster than bat fireballs
        dx = px - self._fx
        dy = py - self._fy
        dist = math.hypot(dx, dy) or 1
        speed = 4.0
        arrow._vx = (dx / dist) * speed
        arrow._vy = (dy / dist) * speed
        return arrow


# ── Skeleton Knight ───────────────────────────────────────────────────────────

class SkeletonKnight(Enemy):
    """
    Armoured melee skeleton.  Tougher and slower than a basic Skeleton,
    carrying a shield that blocks projectiles from the front.

    Mechanics
    ---------
    - 10 HP (tankier than Skeleton's 3 or Archer's 4)
    - Speed 0.9 — heavy armour slows it down vs. basic skeleton
    - contact_damage 2 — hits harder when it reaches the player
    - Shield block: when a projectile hits from the FRONT (within ±60° of
      facing direction), it is deflected and deals no damage.
      Projectiles from the sides or behind still do full damage.
    - Facing direction tracks the player so the shield is meaningful.

    Strategy hint for the player: roll around it, or use the wide arc
    of the Two-Handed Sword / Laser Sword to catch it from the side.
    """

    BLOCK_HALF_ANGLE = math.pi / 3   # ±60° frontal shield arc

    def __init__(self, x, y):
        super().__init__(x=x, y=y, hp=10, speed=0.9, contact_damage=2,
                         sprite_name='skeleton_knight.png')
        self.coin_drop  = random.randint(4, 7)   # better reward for tougher fight
        # Facing angle in radians (updated each frame to track player)
        self._facing_angle = 0.0

    # ── update ────────────────────────────────────────────────────────────────

    def update(self, player, walls):
        # Track facing direction toward player
        dx = player.hitbox.centerx - self._fx
        dy = player.hitbox.centery - self._fy
        if abs(dx) + abs(dy) > 0.5:
            self._facing_angle = math.atan2(dy, dx)

        self._chase(player, walls)

        if self.inv_frames   > 0: self.inv_frames   -= 1
        if self.flash_frames > 0: self.flash_frames -= 1
        self.hitbox.center = (int(self._fx), int(self._fy))
        self.rect.center   = self.hitbox.center
        return None

    # ── shield block ──────────────────────────────────────────────────────────

    def blocks_projectile(self, proj_rect):
        """
        Returns True if the incoming projectile hits the shield (front arc).
        Called by game.py before applying projectile damage.

        The incoming angle is computed from the knight's centre to the
        projectile centre.  If it falls within ±BLOCK_HALF_ANGLE of the
        knight's facing direction it is blocked.
        """
        kx, ky = int(self._fx), int(self._fy)
        px, py = proj_rect.centerx, proj_rect.centery

        # Angle FROM the knight's centre TOWARD the projectile
        incoming_angle = math.atan2(py - ky, px - kx)

        # Angular difference between facing and incoming
        diff = incoming_angle - self._facing_angle
        # Normalise to [-π, π]
        diff = (diff + math.pi) % (2 * math.pi) - math.pi

        # The shield faces the PLAYER (same direction as _facing_angle).
        # A projectile coming FROM the player side arrives roughly opposite,
        # i.e. diff ≈ ±π.  We block when the hit comes from within ±60° of
        # the facing direction (i.e. shield faces toward diff ≈ 0 from knight's
        # perspective means projectile is in front).
        # Re-interpret: if the projectile is in the frontal hemisphere (the knight
        # is facing TOWARD the player, so projectiles coming FROM the player
        # direction have diff near ±π).  We want to block those:
        return abs(abs(diff) - math.pi) < self.BLOCK_HALF_ANGLE


# ═════════════════════════════════════════════════════════════════════════════
# PHASE 6 BOSSES
# ═════════════════════════════════════════════════════════════════════════════

# ── Dragon (mini-boss) ────────────────────────────────────────────────────────

class Dragon(Enemy):
    """
    Mini-boss.  Lumbers toward the player and periodically exhales a
    3-shot fire-breath spread (one aimed directly, two ±30° off-axis).

    Attributes
    ----------
    SPRITE_SIZE   : 56  (larger than regular enemies)
    hp            : 50
    speed         : 0.8 (slow)
    contact_damage: 2   (heavy)
    coin_drop     : 15–25
    FIRE_INTERVAL : 90  frames (1.5 s @ 60 fps)
    """

    SPRITE_SIZE   = 64
    FIRE_INTERVAL = 90
    SPREAD        = math.pi / 6   # 30°

    def __init__(self, x, y):
        super().__init__(
            x=x, y=y,
            hp=50, speed=0.8, contact_damage=2,
            sprite_name='dragon.png',
            sprite_dir=BOSS_DIR,
        )
        self.is_boss   = True
        self.boss_type = 'dragon'
        self.coin_drop = random.randint(15, 25)

        # Larger hitbox to match the bigger sprite
        self.hitbox = pygame.Rect(0, 0, 44, 44)
        self.hitbox.center = self.rect.center

        self.fire_timer = 60   # first breath after 1 second

    # ── update ────────────────────────────────────────────────────────────────

    def update(self, player, walls):
        self._chase(player, walls)
        if self.inv_frames   > 0: self.inv_frames   -= 1
        if self.flash_frames > 0: self.flash_frames -= 1
        self.hitbox.center = (int(self._fx), int(self._fy))
        self.rect.center   = self.hitbox.center

        self.fire_timer -= 1
        if self.fire_timer <= 0:
            self.fire_timer = self.FIRE_INTERVAL
            return self._breathe_fire(player)
        return None

    def _breathe_fire(self, player):
        """Return a list of 3 EnemyProjectiles in a ±30° spread."""
        from weapons import EnemyProjectile
        px, py = player.hitbox.center
        dx = px - self._fx
        dy = py - self._fy
        base_angle = math.atan2(dy, dx)

        fireballs = []
        for delta in (-self.SPREAD, 0, self.SPREAD):
            angle = base_angle + delta
            # Aim point is far away in the spread direction
            tx = self._fx + math.cos(angle) * 400
            ty = self._fy + math.sin(angle) * 400
            fb = EnemyProjectile(
                int(self._fx), int(self._fy),
                int(tx), int(ty),
                damage=1,
            )
            # Override speed for dragon breath (slightly faster than bat fireballs)
            fb._vx = math.cos(angle) * 4.5
            fb._vy = math.sin(angle) * 4.5
            fireballs.append(fb)
        return fireballs

    # ── drawing ───────────────────────────────────────────────────────────────

    def draw(self, surface):
        super().draw(surface)
        # Boss always shows HP bar — even at full health
        if self.hp == self.max_hp:
            self._draw_hp_bar(surface)

    def _draw_hp_bar(self, surface):
        """Wider, taller HP bar befitting a boss."""
        w    = self.SPRITE_SIZE + 8
        x    = self.rect.left - 4
        y    = self.rect.top - 10
        h    = 6
        pygame.draw.rect(surface, (70, 15, 15),  (x,    y, w,    h))
        fill = max(1, int(w * self.hp / self.max_hp))
        pygame.draw.rect(surface, (200, 80, 20), (x,    y, fill, h))   # orange
        pygame.draw.rect(surface, (255, 150, 50),(x,    y, fill, 2))   # top highlight
        # Label
        pygame.font.init()
        font = pygame.font.SysFont('Arial', 10, bold=True)
        lbl  = font.render('DRAGON', True, (255, 180, 80))
        surface.blit(lbl, (x, y - lbl.get_height() - 1))


# ── Skeleton King (final boss) ────────────────────────────────────────────────

class SkeletonKing(Enemy):
    """
    Final boss.  Two-phase fight.

    Phase 1 (HP > PHASE2_HP):
      • Fast charge toward player (speed 1.6)
      • Contact damage 2
      • Bone Volley every ~3 s: 5-shot spread aimed at player

    Phase 2 (HP ≤ PHASE2_HP — ENRAGED):
      • Speed increases to 2.0
      • Bone Volley fires every ~1.8 s AND fires 8 shots instead of 5
      • Bone Spin every ~5 s: 12-projectile ring burst outward in all directions
      • Every SUMMON_INTERVAL frames, places 2 Skeletons in pending_spawns
        (game.py drains this list and adds them to room.enemies)
      • HP bar turns purple
    """

    SPRITE_SIZE     = 64
    PHASE2_HP       = 40           # threshold (50 % of 80)
    SUMMON_INTERVAL = 400          # frames between summons (~6.7 s)

    # Attack timers (frames)
    VOLLEY_INTERVAL_P1 = 180       # ~3 s in phase 1
    VOLLEY_INTERVAL_P2 = 110       # ~1.8 s in phase 2
    SPIN_INTERVAL      = 300       # ~5 s in phase 2

    def __init__(self, x, y):
        super().__init__(
            x=x, y=y,
            hp=80, speed=1.6, contact_damage=2,
            sprite_name='skeleton_king.png',
            sprite_dir=BOSS_DIR,
        )
        self.is_boss   = True
        self.boss_type = 'skeleton_king'
        self.coin_drop = random.randint(30, 50)

        self.hitbox = pygame.Rect(0, 0, 44, 44)
        self.hitbox.center = self.rect.center

        self.summon_timer = self.SUMMON_INTERVAL
        self._in_phase2   = False

        self.volley_timer = self.VOLLEY_INTERVAL_P1
        self.spin_timer   = self.SPIN_INTERVAL

    # ── update ────────────────────────────────────────────────────────────────

    def update(self, player, walls):
        # Phase transition
        if not self._in_phase2 and self.hp <= self.PHASE2_HP:
            self._in_phase2 = True
            self.speed       = 2.0
            self.flash_frames = 30   # dramatic flash on phase change
            # Reset timers on enrage so attacks fire soon after transition
            self.volley_timer = 60
            self.spin_timer   = 120

        self._chase(player, walls)
        if self.inv_frames   > 0: self.inv_frames   -= 1
        if self.flash_frames > 0: self.flash_frames -= 1
        self.hitbox.center = (int(self._fx), int(self._fy))
        self.rect.center   = self.hitbox.center

        projectiles = []

        # Bone volley (both phases)
        self.volley_timer -= 1
        if self.volley_timer <= 0:
            interval = self.VOLLEY_INTERVAL_P2 if self._in_phase2 else self.VOLLEY_INTERVAL_P1
            self.volley_timer = interval
            projectiles.extend(self._bone_volley(player))

        # Phase 2 extras
        if self._in_phase2:
            # Summon skeletons
            self.summon_timer -= 1
            if self.summon_timer <= 0:
                self.summon_timer = self.SUMMON_INTERVAL
                self._queue_summons()

            # Spin burst
            self.spin_timer -= 1
            if self.spin_timer <= 0:
                self.spin_timer = self.SPIN_INTERVAL
                projectiles.extend(self._bone_spin())

        return projectiles if projectiles else None

    # ── attacks ───────────────────────────────────────────────────────────────

    def _bone_volley(self, player):
        """
        Fires a spread of bone projectiles aimed at the player.
        Phase 1: 5 shots in a ±40° arc.
        Phase 2: 8 shots in a ±60° arc.
        """
        from weapons import EnemyProjectile
        px, py = player.hitbox.center
        dx = px - self._fx
        dy = py - self._fy
        base_angle = math.atan2(dy, dx)

        if self._in_phase2:
            count      = 8
            total_arc  = math.pi * 2 / 3   # 120°
        else:
            count      = 5
            total_arc  = math.pi * 4 / 9   # 80°

        shots = []
        for i in range(count):
            t     = i / (count - 1) if count > 1 else 0
            angle = base_angle - total_arc / 2 + t * total_arc
            tx    = self._fx + math.cos(angle) * 600
            ty    = self._fy + math.sin(angle) * 600
            proj  = EnemyProjectile(int(self._fx), int(self._fy),
                                    int(tx), int(ty), damage=1)
            speed = 4.0 if self._in_phase2 else 3.2
            proj._vx = math.cos(angle) * speed
            proj._vy = math.sin(angle) * speed
            proj.image = self._make_bone_image()
            shots.append(proj)
        return shots

    def _bone_spin(self):
        """
        Fires 12 bone projectiles evenly spread in a full 360° ring.
        Enraged phase 2 only.
        """
        from weapons import EnemyProjectile
        shots = []
        count = 12
        for i in range(count):
            angle = (2 * math.pi / count) * i
            tx    = self._fx + math.cos(angle) * 600
            ty    = self._fy + math.sin(angle) * 600
            proj  = EnemyProjectile(int(self._fx), int(self._fy),
                                    int(tx), int(ty), damage=2)
            proj._vx = math.cos(angle) * 3.5
            proj._vy = math.sin(angle) * 3.5
            proj.image = self._make_bone_image(spin=True)
            shots.append(proj)
        return shots

    @staticmethod
    def _make_bone_image(spin=False):
        """Purple/dark bone projectile image distinct from dragon fireballs."""
        from weapons import EnemyProjectile
        sz   = EnemyProjectile.PROJ_SIZE + 2   # slightly larger than bat fireballs
        surf = pygame.Surface((sz, sz), pygame.SRCALPHA)
        cx = cy = sz // 2
        if spin:
            # Bright magenta-white ring burst for the spin attack
            pygame.draw.circle(surf, (200,  60, 255, 120), (cx, cy), sz // 2)
            pygame.draw.circle(surf, (180,  40, 220),      (cx, cy), sz // 3)
            pygame.draw.circle(surf, (240, 200, 255),      (cx, cy), max(2, sz // 6))
        else:
            # Dark purple core with dim violet glow — "bone magic"
            pygame.draw.circle(surf, (100,  20, 160, 110), (cx, cy), sz // 2)
            pygame.draw.circle(surf, (130,  40, 190),      (cx, cy), sz // 3)
            pygame.draw.circle(surf, (210, 170, 255),      (cx, cy), max(2, sz // 6))
        return surf

    def _queue_summons(self):
        """Add 2 Skeleton spawn requests to pending_spawns."""
        cx = ROOM_COLS  // 2 * TILE_SIZE
        cy = ROOM_OFFSET_Y + ROOM_ROWS // 2 * TILE_SIZE
        for _ in range(2):
            # Random position well away from room centre and boss
            for attempt in range(50):
                col = random.randint(3, ROOM_COLS - 4)
                row = random.randint(3, ROOM_ROWS - 4)
                x   = ROOM_OFFSET_X + col * TILE_SIZE + TILE_SIZE // 2
                y   = ROOM_OFFSET_Y + row * TILE_SIZE + TILE_SIZE // 2
                dist_from_boss = math.hypot(x - self._fx, y - self._fy)
                dist_from_cent = math.hypot(x - cx, y - cy)
                if dist_from_boss > 3 * TILE_SIZE and dist_from_cent > 2 * TILE_SIZE:
                    self.pending_spawns.append(Skeleton(x, y))
                    break

    # ── drawing ───────────────────────────────────────────────────────────────

    def draw(self, surface):
        # Purple glow in phase 2
        if self._in_phase2:
            glow = self.image.copy()
            glow.fill((80, 0, 80), special_flags=pygame.BLEND_RGB_ADD)
            if self.flash_frames > 0 and self.flash_frames % 2 == 0:
                glow.fill((200, 200, 200), special_flags=pygame.BLEND_RGB_ADD)
            surface.blit(glow, self.rect)
        else:
            if self.flash_frames > 0 and self.flash_frames % 2 == 0:
                flash = self.image.copy()
                flash.fill((200, 200, 200), special_flags=pygame.BLEND_RGB_ADD)
                surface.blit(flash, self.rect)
            else:
                surface.blit(self.image, self.rect)

        self._draw_hp_bar(surface)

    def _draw_hp_bar(self, surface):
        w    = self.SPRITE_SIZE + 8
        x    = self.rect.left - 4
        y    = self.rect.top - 10
        h    = 6
        pygame.draw.rect(surface, (30, 10, 40),  (x, y, w,    h))
        fill = max(1, int(w * self.hp / self.max_hp))
        bar_col = (160, 0, 200) if self._in_phase2 else (80, 60, 180)
        hi_col  = (220, 80, 255) if self._in_phase2 else (140, 120, 220)
        pygame.draw.rect(surface, bar_col, (x, y, fill, h))
        pygame.draw.rect(surface, hi_col,  (x, y, fill, 2))

        phase_str = ' — ENRAGED!' if self._in_phase2 else ''
        pygame.font.init()
        font = pygame.font.SysFont('Arial', 10, bold=True)
        lbl_col = (220, 80, 255) if self._in_phase2 else (180, 160, 220)
        lbl  = font.render(f'SKELETON KING{phase_str}', True, lbl_col)
        surface.blit(lbl, (x, y - lbl.get_height() - 1))
