# Ben's Dungeon Adventure — Project Bible

> **Game title: "The Dark Keep"**

## Game Overview
A top-down dungeon crawler in the style of NES The Legend of Zelda. The player navigates through a dark stone castle dungeon (10–15 rooms), battles enemies, collects coins, shops for upgrades, and defeats a dragon mini-boss and the Skeleton King final boss to win.

### Confirmed Design Decisions
| Element           | Decision                  |
|-------------------|---------------------------|
| Player            | A wizard                  |
| Wizard robe color | Amber (golden-orange)     |
| Starting weapon   | Lightning Rod             |
| Mini-boss         | A dragon                  |
| Final boss        | The Skeleton King         |
| Dungeon theme     | Dark stone castle         |
| Game name         | **The Dark Keep**         |

---

## Technical Stack
- **Language:** Python 3
- **Library:** Pygame
- **Graphics:** Pixel art sprites (PNG files generated programmatically or by hand)
- **Platform:** Windows
- **Entry point:** `main.py`
- **Run command:** `python main.py`

---

## Folder Structure
```
Ben_Video_Game/
├── CLAUDE.md           ← this file
├── main.py             ← game entry point
├── settings.py         ← constants (screen size, FPS, colors, damage values)
├── game.py             ← main game loop and state manager
├── player.py           ← player class
├── enemy.py            ← enemy and boss classes
├── room.py             ← room and dungeon layout
├── weapons.py          ← weapon classes and logic
├── ui.py               ← HUD (hearts, coins, weapon display)
├── shop.py             ← shopkeeper and shop menu
├── sprites/            ← all PNG sprite images
│   ├── player/
│   ├── enemies/
│   ├── bosses/
│   ├── weapons/
│   ├── tiles/
│   └── ui/
└── sounds/             ← sound effects (future phase)
```

---

## Game Design

### Player
- Top-down movement (up/down/left/right, WASD or arrow keys)
- Starts with **3 hearts**
- Hearts can be lost by taking damage, found in rooms to restore
- Can equip one weapon at a time
- Has a coin counter
- Can collect **armor upgrades** to reduce damage taken

### Hearts System
- Player starts with 3 hearts
- Each heart = 1 hit point (can extend to half-hearts later)
- When hearts reach 0 → Game Over screen
- Extra hearts can be found hidden in rooms or bought in shop

### Weapons
All weapons have different attack range, speed, and damage:

| Weapon           | Damage | Range  | Attack Speed | Notes                              |
|------------------|--------|--------|--------------|-------------------------------------|
| Lightning Rod    | 2      | Short  | Fast         | Starting weapon, zaps enemies       |
| Spear            | 3      | Medium | Medium       | Hits in a line                      |
| Bow              | 2      | Long   | Slow         | Fires arrow projectile              |
| Two-Handed Sword | 4      | Short  | Slow         | Wide arc, high damage               |
| Laser Gun        | 5      | Long   | Medium       | Fires laser beam projectile         |
| Laser Sword      | 7      | Long   | Medium       | 3-bolt 90° arc, post-dragon reward  |
| Ice Sword        | 6      | Long   | Slow         | Single homing orb, tracks enemies   |

### Enemies
- **Basic enemy:** Skeleton — moves toward player, melee attack
- **Ranged enemy:** Bat or dark archer — keeps distance, fires projectile
- **Mini-boss:** Dragon — large sprite, breathes fire (projectile), more HP
- **Final boss:** Skeleton King — multi-phase fight; phase 1 melee + bone volley spread, phase 2 faster volley, bone spin ring burst + summons skeletons

### Dungeon Layout (10–15 rooms)
- Rooms are connected by doorways (north/south/east/west)
- Each room is a fixed screen (no scrolling within a room)
- Player transitions to next room when they walk through a doorway
- Room types:
  - **Combat rooms** — enemies to defeat
  - **Treasure rooms** — weapon or item found here
  - **Coin rooms** — coins scattered, maybe a chest
  - **Shop room** — shopkeeper lives here
  - **Mini-boss room** — one in the middle of the dungeon
  - **Boss room** — final room, locked until mini-boss is defeated
  - **Safe/empty rooms** — rest areas with no enemies

### Shopkeeper
- Lives in a dedicated room
- Player presses E to talk to him
- He sells:
  - Weapon upgrades (costs coins)
  - Armor upgrade (costs coins, reduces damage by 1)
  - Extra heart container (costs coins)
- After buying, the item disappears from his stock

### Coins
- Dropped by defeated enemies
- Found in treasure/coin rooms
- Used at the shop

### Armor
- Armor upgrade reduces all incoming damage by 1 (min 1)
- Can be bought at the shop or found in a treasure room
- Show armor status on HUD

---

## Build Phases

### ✅ Phase 1 — Foundation (COMPLETE)
- [x] Game window and main loop
- [x] Player sprite (pixel art, wizard) with 4-directional movement
- [x] Single room with stone wall and floor tiles
- [x] Camera stays fixed (Zelda style — full room on screen)
- [x] Basic collision with walls
- [x] HUD: hearts display, coin counter, equipped weapon

### ✅ Phase 2 — Dungeon Rooms (COMPLETE)
- [x] Room class with tile map and door openings
- [x] 12 rooms connected by doors (N/S/E/W)
- [x] Room transition (fade to black) when player walks through a door
- [x] Locked door system (Skeleton King room locked until dragon is defeated)
- [x] Dungeon map layout defined (12 rooms, see dungeon.py)

### ✅ Phase 3 — Combat (COMPLETE)
- [x] Projectile attack — hold SPACE or Z to fire Lightning Rod bolts in facing direction
- [x] Enemy class (enemy.py): Skeleton — chases player, deals melee contact damage
- [x] Enemy AI: smooth movement with axis-separated wall collision
- [x] Hearts reduced when player takes contact damage (1 heart per touch)
- [x] Enemy dies when HP reaches 0; drops 1–3 coins credited instantly
- [x] Invincibility frames on player after damage (60 frames / 1 s flicker)
- [x] Brief invincibility on enemies after hit (prevents multi-frame single-bolt damage)
- [x] HP bar visible above enemies once damaged; white flash when struck
- [x] Game Over screen — press R to restart

### ✅ Phase 4 — Weapons & Items (COMPLETE)
- [x] Spear, Bow, Two-Handed Sword, Laser Gun projectiles with tuned speed/size/color
- [x] Weapon switching: Q to cycle owned weapons; keys 1–6 to equip directly
- [x] Weapons found in rooms: Spear (The Armory), Bow (Ancient Shrine),
       Two-Handed Sword (Hall of Bones), Laser Gun (Forbidden Vault)
- [x] HUD inventory bar — 6 weapon slots, active weapon gold-bordered, locked slots dimmed
- [x] Two-Handed Sword fires a 3-bolt 60° fan arc with short lifetime (melee feel)
- [x] Per-weapon projectile speeds: Laser Sword 13, Laser 11, Sword 9, Lightning/Spear 7, Bow 5 px/frame
- [x] Coins dropped by enemies as pickup objects on the floor (walk over to collect)
- [x] Coin rooms: 8 scattered coins in The Treasury, 5 in Hall of Bones
- [x] Weapon pickup notification banner: "Got the X! Press Q to switch weapons"
- [x] Weapon pickup sprites: spear, bow, two_handed_sword, laser_gun PNG files
- [x] pickups.py — WeaponPickup and CoinPickup classes with bobbing animation

### ✅ Phase 5 — Shop & Upgrades (COMPLETE)
- [x] Shopkeeper NPC drawn in The Wandering Merchant room (pixel-art teal robe, hat, coin bag)
- [x] "[E] Shop" prompt floats above his head when player is within 3 tiles
- [x] Shop menu overlay: UP/DOWN to navigate, E to buy, ESC to leave
- [x] Armor upgrade (×2 max): each reduces incoming damage by 1 — shield badge shown in HUD
- [x] Heart container: adds 1 max heart (up to 6), also restores 1 heart immediately
- [x] Weapon purchases: all un-owned weapons available (prices: Spear 10, Bow 12, Sword 15, Laser 25)
- [x] After buying, item is removed from current session stock
- [x] Red price shown when player can't afford; flash message on buy/fail
- [x] ESC closes the shop (no longer quits game); ESC outside shop still quits

### ✅ Phase 6 — Bosses (COMPLETE)
- [x] Mini-boss: Dragon — 56 px sprite, 50 HP, 3-shot fire-breath spread (±30°), contact damage 2
- [x] Mini-boss room locked (S door opens when Dragon dies, notification shown)
- [x] Final boss: Skeleton King — 80 HP, phase 1 speed 1.6 → phase 2 speed 2.0 at ≤40 HP
- [x] Skeleton King phase 1: bone volley every ~3 s (5-shot 80° spread, purple projectiles, damage 1)
- [x] Skeleton King phase 2 summons 2 Skeletons every ~6.7 s (purple glow, "ENRAGED!" label)
- [x] Skeleton King phase 2: bone volley every ~1.8 s (8-shot 120° spread) + bone spin burst every ~5 s (12-shot 360° ring, damage 2, bright magenta)
- [x] Victory screen when Skeleton King is defeated (press R to play again)

### ✅ Phase 7 — Polish (COMPLETE)
- [x] Sound effects — 12 procedurally-generated 8-bit sounds via numpy (fire, hit, hurt, coin,
       weapon_pickup, door_unlock, boss_death, victory, game_over, menu_move, menu_confirm,
       menu_start); degrades gracefully if numpy unavailable
- [x] Walk animations — 2-frame cycle per direction (idle ↔ walk frame, toggles every 9 frames);
       snaps to idle when stationary; attack flash overlay (amber glow, 7 frames)
- [x] Main menu screen — atmospheric stone-tile background, animated torch flames, gold gradient
       title, wizard sprite, blinking "PRESS ENTER TO BEGIN" prompt; ENTER/SPACE to start
- [x] Minimap — fog-of-war overlay in bottom-right corner; rooms colour-coded by type;
       door connectors between adjacent visited rooms; white dot = player position

### ✅ Phase 8 — Expansion (COMPLETE)
- [x] 10 new rooms between Dragon and Skeleton King (bat cave, rest rooms, zombie crypt,
       second shop, crypt passage, bone vault, dark corridor, eerie shrine, crypt depths,
       king's antechamber) — dungeon grows from 13 → 22 rooms
- [x] HeartContainerPickup — glowing golden heart in Bat Cave; permanently raises max hearts
- [x] Static heart pickups scattered in rest/shrine rooms
- [x] Roll dodge — Shift key; 3× speed dash in facing direction, i-frames, cyan ghost trail,
       HUD cooldown ring; 1.5 s cooldown
- [x] Skeleton Archer — ranged skeleton; backs away from player, fires bone arrows every 1.5 s;
       4 HP, faster than basic skeleton; appears in crypt passage, dark corridor, king's antechamber
- [x] Chest system — locked chests placed in Hall of Bones, Bone Vault, Crypt Depths;
       chest keys drop from enemies at ~5% rate; press E near chest to open (yields 5–12 coins,
       40% heart, 15% heart container); key count shown in HUD
- [x] Boss health bars — full-width cinematic bar at screen bottom when Dragon or Skeleton King
       is alive; shows name, HP fraction, phase-aware colour (orange for Dragon, purple for King)
- [x] Bomb damage increased to 20 (one-shots skeletons/bats, heavily wounds zombies)

### ✅ Phase 9 — Extra Polish (COMPLETE)
- [x] Torch wall decorations — animated 3-frame flame torches mounted on inner border walls
       at fixed positions (north/south/east/west); warm glow halo, flickering independently per
       torch using staggered sine-wave phases; drawn in `room.draw()` after tiles
- [x] Boss room enter fanfare — 1.5 s enemy-freeze + screen shake (0.5 s) + white flash on
       first entry to Dragon Lair or Throne of the Skeleton King; boss activates after freeze
       ends; only triggers once per room per game session
- [x] Coin magnet on roll — while player roll_frames > 0, all coins within 5 tiles are
       pulled toward player at 8 px/frame; collected on contact as normal
- [x] Boss sprites enlarged from 56×56 to 64×64 (Dragon and Skeleton King)
- [x] Secret rooms — 2 rooms accessible only by bombing a cracked wall:
       "Hidden Vault" (E of The Treasury, grid 4,0): 20 coins jackpot;
       "The Armory Cache" (E of The Watch Tower, grid 4,1): BombPickup bag (+5 bombs);
       cracked-wall overlay with bomb icon marks the breakable passage;
       `BombPickup` class added to pickups.py; dungeon grows from 22 → 24 rooms
- [x] Controls overlay — press TAB anytime during play to open a full-screen panel showing
       every control grouped by section (movement, combat, interaction, menus) and live
       player stats (hearts, coins, armor, bombs, keys) plus weapon damage table;
       ESC or TAB closes it; `[TAB] Controls` hint shown in HUD strip at all times
- [x] Roll tutorial hint — blinking banner in the start room only: "Press [Left Alt] to Roll-Dodge!"
       with secondary tip about i-frames and coin magnet; dismisses automatically the moment
       the player rolls or leaves the start room; uses smooth sine-wave alpha pulse
- [x] Laser Sword — post-dragon ultimate weapon (damage 7, speed 13 px/frame); fires a wide
       3-bolt 90° arc of vivid magenta energy bolts at full room range; found in
       "The Dragon's Hoard" (grid 3,4, E of Dragon's Lair); slot 6 in HUD; press 6 to equip

### ✅ Bug Fix Batch (COMPLETE)
- [x] Mystery Key — one per session; removed from all shops after purchase
- [x] Roll indicator — smaller ring, repositioned left-side below hearts (above TAB hint)
- [x] Tab hint text changed to "Press [Tab] to View Controls"
- [x] Roll dodge key changed from Shift → Left Alt (prevents sticky keys)
- [x] Start room center south torch removed (was overlaying mystery door)
- [x] Notification banner given dark backdrop for readability
- [x] Bombs icon moved below coins in HUD centre column (no longer behind weapon slots)
- [x] Dragon room center south torch removed after dragon dies (door opens, torch rebuilds)
- [x] Bat Cave bats now stationary in a circle around the heart container, firing only
- [x] Dragon's Hoard (E door) now connected to Dragon's Lair; locked until dragon dies
- [x] Eerie Shrine and Depths of the Crypt rooms removed (dungeon: 23 rooms total)
- [x] Roll wall-stuck bug fixed — collision resolver uses roll velocity during a roll

### 💡 Ideas Backlog
| Idea | Priority | Notes |
|------|----------|-------|
| Floating damage numbers | Medium | "-2", "-5" pop above enemies on hit |

---

## Questions & Decisions Log

- [x] What is the player character? → **A wizard**
- [x] What is the mini-boss? → **A dragon**
- [x] What is the final boss? → **The Skeleton King**
- [x] What is the dungeon theme? → **Dark stone castle**
- [x] What is the game's name? → **The Dark Keep**
- [x] What color is the wizard's robe? → **Amber (golden-orange)**
- [x] Does the wizard have a staff or a wand? → **Lightning Rod** (starting weapon)

---

## Current Status
**Phase 9 COMPLETE + Bug Fix Batch — The Dark Keep is fully playable end-to-end.**
All nine build phases implemented, plus post-Phase-9 additions and bug fixes:
- Phases 1–7: foundation, dungeon, combat, weapons/items, shop/upgrades, bosses, polish
- Phase 8: new rooms, skeleton archer, chest system, boss health bars, roll dodge, bomb buff
- Phase 9: wall torches, boss fanfare, coin magnet on roll, secret rooms, boss sprites 64×64,
           TAB controls overlay, roll tutorial hint
- Post-Phase-9: Laser Sword (ultimate weapon), dungeon now 23 rooms total
- Bug fixes: mystery key stock, HUD layout, roll key (Left Alt), torch fixes, bat circle AI,
             dungeon restructure, roll wall-stuck fix

### Controls
| Key            | Action                                    |
|----------------|-------------------------------------------|
| WASD / Arrows  | Move                                      |
| SPACE / Z      | Attack (hold to fire)                     |
| Left Alt       | Roll dodge (1.5 s cooldown)               |
| Q              | Cycle to next owned weapon                |
| 1 – 6          | Equip specific weapon slot                |
| E              | Talk to shopkeeper / Buy item / Open chest|
| B              | Plant bomb                                |
| TAB            | Open / close controls overlay             |
| ESC            | Close shop / controls / Quit game         |
| R              | Restart (Game Over screen)                |
