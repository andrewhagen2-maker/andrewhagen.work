"""
generate_sprites.py
-------------------
Creates all pixel-art PNG sprites used by the game.
Run this once (main.py calls it automatically if sprites are missing).

Each sprite is drawn on a 16×16 grid and scaled up 2× → 32×32 output.
"""

import os
try:
    from PIL import Image
except ImportError:
    Image = None  # PIL not available in wasm — sprite generation is skipped

BASE = os.path.dirname(os.path.abspath(__file__))
SPR  = os.path.join(BASE, 'sprites')


# ── palette ──────────────────────────────────────────────────────────────────
_ = (  0,   0,   0,   0)   # transparent

# Wizard palette
S  = (255, 200, 150, 255)  # skin
E  = ( 30,  20,  10, 255)  # eyes / dark outline
HA = ( 55,  25,  90, 255)  # hat – dark purple
Ha = ( 90,  50, 140, 255)  # hat – highlight
H  = ( 38,  18,  65, 255)  # hat shadow / outline
WB = (240, 240, 248, 255)  # white beard
P  = (220, 155,  30, 255)  # robe – amber / golden-orange
p  = (155, 100,  12, 255)  # robe – amber shadow fold
ST = (150, 100,  40, 255)  # staff / lightning rod – wood/metal brown
Sg = ( 80, 210, 255, 255)  # rod tip gem – bright cyan-blue
Sk = ( 40, 140, 200, 255)  # rod gem shadow

# Heart / coin / UI
R  = (220,  50,  50, 255)  # red heart
r  = (140,  25,  25, 255)  # heart shadow
D  = (100,  85,  70, 255)  # empty heart
GO = (255, 205,  50, 255)  # gold coin
Gd = (190, 145,  20, 255)  # coin dark
Gh = (255, 240, 140, 255)  # coin highlight

# Sword
C  = (190, 190, 200, 255)  # blade
c  = (130, 130, 140, 255)  # blade shadow
N  = (130,  90,  40, 255)  # handle
n  = ( 90,  60,  20, 255)  # handle shadow

# Skeleton enemy
SK = (220, 215, 200, 255)  # bone
SW = (245, 240, 230, 255)  # bone highlight
SD = ( 30,  25,  20, 255)  # dark eye socket / hollow
Sd = (160, 150, 130, 255)  # bone shadow

# Zombie enemy
ZG = (120, 150,  90, 255)  # zombie flesh — sickly green
Zg = ( 75, 100,  55, 255)  # zombie flesh shadow
ZE = (210,  50,  50, 255)  # undead red eyes
ZR = (140,  50,  35, 255)  # rotted / blood detail
ZH = ( 50,  60,  35, 255)  # matted dark hair

# Bat enemy
BW = ( 45,  25,  75, 255)  # wing — dark purple
Bw = ( 80,  50, 120, 255)  # wing highlight
BB = ( 20,  12,  35, 255)  # body — near-black purple
BE = (210,  50,  50, 255)  # red eyes
Bf = ( 55,  35,  80, 255)  # feet / claws

# Floor / wall
F  = (130, 118, 105, 255)  # floor base
F1 = (148, 135, 122, 255)  # floor highlight
F2 = (108,  96,  83, 255)  # floor grout
WA = ( 78,  65,  52, 255)  # wall base
W1 = (105,  90,  75, 255)  # wall highlight
W2 = ( 52,  42,  30, 255)  # wall shadow


# ── helper ────────────────────────────────────────────────────────────────────

def make_image(pixels, scale=2):
    h = len(pixels)
    w = len(pixels[0])
    img = Image.new('RGBA', (w * scale, h * scale), (0, 0, 0, 0))
    for y, row in enumerate(pixels):
        for x, col in enumerate(row):
            if col != _:
                for dy in range(scale):
                    for dx in range(scale):
                        img.putpixel((x * scale + dx, y * scale + dy), col)
    return img


def save(img, *path_parts):
    path = os.path.join(SPR, *path_parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)
    print(f'  saved {os.path.relpath(path, BASE)}')


# ── WIZARD PLAYER SPRITES  (16×16 → 32×32) ───────────────────────────────────
#
#  Layout key  (columns 0-15, rows 0-15):
#    Hat tip      rows 0-2  (pointy top)
#    Hat brim     row 3
#    Face         rows 4-6
#    Robe         rows 7-11
#    Feet         rows 12-13
#

def wizard_down():
    """Facing the player (front view)."""
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  _,  _,  _,  HA, _,  _,  _,  _,  _,  _,  _,  _,  _],   # 0
        [_,  _,  _,  _,  _,  HA, Ha, HA, _,  _,  _,  _,  _,  _,  _,  _],   # 1
        [_,  _,  _,  _,  HA, Ha, HA, Ha, HA, _,  _,  _,  _,  _,  _,  _],   # 2
        [_,  _,  _,  H,  HA, HA, HA, HA, HA, HA, H,  _,  _,  _,  _,  _],   # 3 brim
        [_,  _,  _,  H,  S,  S,  S,  S,  S,  H,  _,  _,  _,  _,  _,  _],   # 4 face
        [_,  _,  _,  H,  S,  E,  S,  S,  E,  H,  _,  _,  _,  _,  _,  _],   # 5 eyes
        [_,  _,  _,  H,  WB, WB, WB, WB, WB, H,  _,  _,  _,  _,  _,  _],   # 6 beard
        [_,  _,  P,  P,  P,  P,  P,  P,  P,  P,  P,  P,  _,  _,  _,  _],   # 7 robe
        [_,  _,  P,  P,  p,  P,  P,  P,  P,  p,  P,  P,  _,  _,  _,  _],   # 8 robe fold
        [_,  _,  P,  Sg, P,  P,  P,  P,  P,  P,  Sg, P,  _,  _,  _,  _],   # 9 robe star
        [_,  _,  P,  P,  P,  P,  P,  P,  P,  P,  P,  P,  _,  _,  _,  _],   # 10 robe
        [_,  ST, P,  P,  P,  P,  P,  P,  P,  P,  P,  _,  _,  _,  _,  _],   # 11 robe+staff
        [_,  ST, _,  P,  P,  _,  _,  _,  _,  P,  P,  _,  _,  _,  _,  _],   # 12 feet
        [_,  ST, _,  P,  P,  _,  _,  _,  _,  P,  P,  _,  _,  _,  _,  _],   # 13 feet
        [_,  Sg, _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 14 staff gem
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 15
    ]


def wizard_up():
    """Back view (walking away)."""
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  _,  _,  _,  HA, _,  _,  _,  _,  _,  _,  _,  _,  _],   # 0
        [_,  _,  _,  _,  _,  HA, Ha, HA, _,  _,  _,  _,  _,  _,  _,  _],   # 1
        [_,  _,  _,  _,  HA, Ha, HA, Ha, HA, _,  _,  _,  _,  _,  _,  _],   # 2
        [_,  _,  _,  H,  HA, HA, HA, HA, HA, HA, H,  _,  _,  _,  _,  _],   # 3 brim
        [_,  _,  _,  H,  HA, HA, HA, HA, HA, H,  _,  _,  _,  _,  _,  _],   # 4 hat back
        [_,  _,  _,  H,  HA, Ha, HA, HA, Ha, H,  _,  _,  _,  _,  _,  _],   # 5 hat back
        [_,  _,  _,  H,  HA, HA, HA, HA, HA, H,  _,  _,  _,  _,  _,  _],   # 6 hat back
        [_,  _,  P,  P,  P,  P,  P,  P,  P,  P,  P,  P,  _,  _,  _,  _],   # 7 robe
        [_,  _,  P,  P,  p,  P,  P,  P,  P,  p,  P,  P,  _,  _,  _,  _],   # 8 fold
        [_,  _,  P,  Sg, P,  P,  P,  P,  P,  P,  Sg, P,  _,  _,  _,  _],   # 9 stars
        [_,  _,  P,  P,  P,  P,  P,  P,  P,  P,  P,  P,  _,  _,  _,  _],   # 10
        [_,  ST, P,  P,  P,  P,  P,  P,  P,  P,  P,  _,  _,  _,  _,  _],   # 11 staff
        [_,  ST, _,  P,  P,  _,  _,  _,  _,  P,  P,  _,  _,  _,  _,  _],   # 12 feet
        [_,  ST, _,  P,  P,  _,  _,  _,  _,  P,  P,  _,  _,  _,  _,  _],   # 13 feet
        [_,  Sg, _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 14 gem
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 15
    ]


def wizard_right():
    """Side view (facing right), staff extended forward."""
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  _,  _,  _,  HA, _,  _,  _,  _,  _,  _,  _,  _,  _],   # 0
        [_,  _,  _,  _,  _,  HA, Ha, HA, _,  _,  _,  _,  _,  _,  _,  _],   # 1
        [_,  _,  _,  _,  HA, Ha, HA, Ha, _,  _,  _,  _,  _,  _,  _,  _],   # 2
        [_,  _,  _,  HA, HA, HA, HA, HA, HA, _,  _,  _,  _,  _,  _,  _],   # 3 brim
        [_,  _,  _,  _,  S,  S,  S,  S,  H,  _,  _,  _,  _,  _,  _,  _],   # 4 face
        [_,  _,  _,  _,  S,  E,  S,  S,  H,  _,  _,  _,  _,  _,  _,  _],   # 5 eye
        [_,  _,  _,  _,  WB, WB, WB, _,  _,  _,  _,  _,  _,  _,  _,  _],   # 6 beard
        [_,  _,  _,  P,  P,  P,  P,  P,  P,  ST, Sg, _,  _,  _,  _,  _],   # 7 robe+staff raised
        [_,  _,  P,  P,  p,  P,  P,  P,  P,  _,  _,  _,  _,  _,  _,  _],   # 8 robe fold
        [_,  _,  P,  Sg, P,  P,  P,  P,  _,  _,  _,  _,  _,  _,  _,  _],   # 9 star
        [_,  _,  P,  P,  P,  P,  P,  P,  _,  _,  _,  _,  _,  _,  _,  _],   # 10
        [_,  ST, P,  P,  P,  P,  P,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 11 staff bottom
        [_,  ST, _,  P,  P,  _,  P,  P,  _,  _,  _,  _,  _,  _,  _,  _],   # 12 feet
        [_,  ST, _,  P,  P,  _,  P,  P,  _,  _,  _,  _,  _,  _,  _,  _],   # 13 feet
        [_,  Sg, _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 14 gem
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 15
    ]


# ── TILE sprites  (20×20 → 40×40) ─────────────────────────────────────────────

def floor_tile():
    p = [
        [F2,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F2],
        [F2,F1,F1,F1,F1,F1,F1,F1,F1,F2,F2,F1,F1,F1,F1,F1,F1,F1,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F1,F1,F1,F1,F1,F1,F1,F2,F2,F1,F1,F1,F1,F1,F1,F1,F1,F2],
        [F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2],
        [F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2,F2],
        [F2,F1,F1,F1,F1,F1,F1,F1,F1,F2,F2,F1,F1,F1,F1,F1,F1,F1,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F ,F ,F ,F ,F ,F ,F1,F2,F2,F1,F ,F ,F ,F ,F ,F ,F1,F2],
        [F2,F1,F1,F1,F1,F1,F1,F1,F1,F2,F2,F1,F1,F1,F1,F1,F1,F1,F1,F2],
        [F2,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F ,F2],
    ]
    return p


def wall_tile():
    p = [
        [W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2],
        [W2,W1,W1,W1,W1,W1,W1,W1,W1,W2,W2,W1,W1,W1,W1,W1,W1,W1,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,W1,W1,W1,W1,W1,W1,W1,W2,W2,W1,W1,W1,W1,W1,W1,W1,W1,W2],
        [W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2],
        [W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2],
        [W2,W1,W1,W1,W1,W1,W1,W1,W1,W2,W2,W1,W1,W1,W1,W1,W1,W1,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,WA,WA,WA,WA,WA,WA,W1,W2,W2,W1,WA,WA,WA,WA,WA,WA,W1,W2],
        [W2,W1,W1,W1,W1,W1,W1,W1,W1,W2,W2,W1,W1,W1,W1,W1,W1,W1,W1,W2],
        [W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2,W2],
    ]
    return p


# ── UI sprites ────────────────────────────────────────────────────────────────

def heart_full():
    """12×12 → 24×24."""
    return [
        [_,R,R,_,_,R,R,_,_,_,_,_],
        [R,R,R,R,R,R,R,R,_,_,_,_],
        [R,r,R,R,R,R,R,R,_,_,_,_],
        [R,R,R,R,R,R,R,R,_,_,_,_],
        [_,R,R,R,R,R,R,_,_,_,_,_],
        [_,_,R,R,R,R,_,_,_,_,_,_],
        [_,_,_,R,R,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
    ]


def heart_empty():
    """12×12 → 24×24."""
    return [
        [_,D,D,_,_,D,D,_,_,_,_,_],
        [D,_,_,D,D,_,_,D,_,_,_,_],
        [D,_,_,_,_,_,_,D,_,_,_,_],
        [D,_,_,_,_,_,_,D,_,_,_,_],
        [_,D,_,_,_,_,D,_,_,_,_,_],
        [_,_,D,_,_,D,_,_,_,_,_,_],
        [_,_,_,D,D,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
        [_,_,_,_,_,_,_,_,_,_,_,_],
    ]


def coin_sprite():
    """8×8 → 16×16."""
    return [
        [_,  _,  GO, GO, GO, _,  _,  _],
        [_,  GO, Gh, Gd, Gd, GO, _,  _],
        [GO, Gh, GO, Gd, Gd, Gd, GO, _],
        [GO, Gh, GO, Gd, Gd, Gd, GO, _],
        [GO, GO, GO, GO, GO, GO, GO, _],
        [_,  GO, Gd, Gd, Gd, GO, _,  _],
        [_,  _,  GO, GO, GO, _,  _,  _],
        [_,  _,  _,  _,  _,  _,  _,  _],
    ]


# ── LIGHTNING ROD sprite  (16×16 → 32×32) ────────────────────────────────────
# Diagonal silver rod with a crackling lightning tip.

# extra colours just for this sprite
LB = (255, 248,  80, 255)  # lightning bright yellow
LO = (255, 195,  40, 255)  # lightning orange-gold
Rd = (185, 190, 205, 255)  # rod silver
Rs = (115, 120, 138, 255)  # rod shadow

def lightning_rod_sprite():
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  _,  LB, _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 0 bolt tip
        [_,  _,  _,  LB, LB, LB, _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 1 bolt spread
        [_,  _,  LB, LO, LB, _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 2 bolt base
        [_,  _,  LO, Rd, Rs, _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 3 rod start
        [_,  _,  _,  Rd, Rs, _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 4
        [_,  _,  _,  _,  Rd, Rs, _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 5
        [_,  _,  _,  _,  Rd, Rs, _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 6
        [_,  _,  _,  _,  _,  Rd, Rs, _,  _,  _,  _,  _,  _,  _,  _,  _],   # 7
        [_,  _,  _,  _,  _,  Rd, Rs, _,  _,  _,  _,  _,  _,  _,  _,  _],   # 8
        [_,  _,  _,  _,  _,  _,  Rd, Rs, _,  _,  _,  _,  _,  _,  _,  _],   # 9
        [_,  _,  _,  _,  _,  _,  Rd, Rs, _,  _,  _,  _,  _,  _,  _,  _],   # 10
        [_,  _,  _,  _,  _,  _,  _,  Rd, Rs, _,  _,  _,  _,  _,  _,  _],   # 11
        [_,  _,  _,  _,  _,  _,  _,  Rs, Rd, _,  _,  _,  _,  _,  _,  _],   # 12 handle end
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 13
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 14
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],   # 15
    ]


# ── SKELETON ENEMY SPRITE  (16×16 → 32×32) ────────────────────────────────────

def skeleton_sprite():
    """Skeleton enemy facing forward."""
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  _,  _,  SK, SK, SK, SK, _,  _,  _,  _,  _,  _,  _],  # 0  skull top
        [_,  _,  _,  _,  SK, SW, SK, SK, SW, SK, _,  _,  _,  _,  _,  _],  # 1  skull highlights
        [_,  _,  _,  _,  SK, SK, SK, SK, SK, SK, _,  _,  _,  _,  _,  _],  # 2  skull mid
        [_,  _,  _,  _,  SK, SD, SK, SK, SD, SK, _,  _,  _,  _,  _,  _],  # 3  eye sockets
        [_,  _,  _,  _,  SK, SD, SK, SK, SD, SK, _,  _,  _,  _,  _,  _],  # 4  eye sockets
        [_,  _,  _,  _,  SK, SK, Sd, Sd, SK, SK, _,  _,  _,  _,  _,  _],  # 5  jaw / teeth
        [_,  _,  _,  _,  _,  SK, SK, SK, SK, _,  _,  _,  _,  _,  _,  _],  # 6  neck
        [_,  _,  SK, SK, SK, SK, SK, SK, SK, SK, SK, SK, _,  _,  _,  _],  # 7  shoulders
        [_,  SK, SK, _,  Sd, SK, SK, SK, SK, Sd, _,  SK, SK, _,  _,  _],  # 8  upper arms
        [SK, SK, _,  _,  SK, SK, SK, SK, SK, SK, _,  _,  SK, SK, _,  _],  # 9  arms extended
        [SK, _,  _,  _,  SK, SK, SK, SK, SK, SK, _,  _,  _,  SK, _,  _],  # 10 arm tips
        [_,  _,  _,  _,  SK, SK, SK, SK, SK, SK, _,  _,  _,  _,  _,  _],  # 11 lower torso
        [_,  _,  _,  _,  _,  SK, Sd, Sd, SK, _,  _,  _,  _,  _,  _,  _],  # 12 upper legs
        [_,  _,  _,  _,  _,  SK, _,  _,  SK, _,  _,  _,  _,  _,  _,  _],  # 13 lower legs
        [_,  _,  _,  _,  SK, SK, _,  _,  SK, SK, _,  _,  _,  _,  _,  _],  # 14 feet
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 15
    ]


# ── ZOMBIE ENEMY SPRITE  (16×16 → 32×32) ──────────────────────────────────────

def zombie_sprite():
    """Slow undead with raised arms and sickly green flesh."""
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  ZH, ZH, ZH, ZH, ZH, ZH, ZH, _,  _,  _,  _,  _,  _],  # 0  hair
        [_,  _,  ZH, ZG, ZG, ZG, ZG, ZG, ZG, ZG, ZH, _,  _,  _,  _,  _],  # 1  skull top
        [_,  _,  _,  ZG, ZG, ZG, ZG, ZG, ZG, ZG, _,  _,  _,  _,  _,  _],  # 2  skull
        [_,  _,  _,  ZG, ZE, ZG, ZG, ZG, ZE, ZG, _,  _,  _,  _,  _,  _],  # 3  red eyes
        [_,  _,  _,  ZG, ZG, ZG, ZG, ZG, ZG, ZG, _,  _,  _,  _,  _,  _],  # 4  mid-face
        [_,  _,  _,  ZG, ZG, ZR, ZR, ZR, ZG, ZG, _,  _,  _,  _,  _,  _],  # 5  decayed mouth
        [_,  _,  _,  _,  ZG, ZG, ZG, ZG, ZG, _,  _,  _,  _,  _,  _,  _],  # 6  neck
        [_,  _,  ZG, ZG, ZG, ZG, ZG, ZG, ZG, ZG, ZG, ZG, _,  _,  _,  _],  # 7  shoulders
        [_,  ZG, ZG, Zg, ZG, ZG, ZG, ZG, ZG, ZG, Zg, ZG, ZG, _,  _,  _],  # 8  upper arms
        [ZG, ZG, _,  _,  ZG, ZG, ZG, ZG, ZG, ZG, _,  _,  ZG, ZG, _,  _],  # 9  arms outstretched
        [ZG, _,  _,  _,  ZG, ZG, ZG, ZG, ZG, ZG, _,  _,  _,  ZG, _,  _],  # 10 arm ends
        [_,  _,  _,  _,  ZG, ZG, ZG, ZG, ZG, ZG, _,  _,  _,  _,  _,  _],  # 11 lower torso
        [_,  _,  _,  _,  _,  ZG, Zg, Zg, ZG, _,  _,  _,  _,  _,  _,  _],  # 12 upper legs
        [_,  _,  _,  _,  _,  ZG, _,  _,  ZG, _,  _,  _,  _,  _,  _,  _],  # 13 lower legs
        [_,  _,  _,  _,  ZG, ZG, _,  _,  ZG, ZG, _,  _,  _,  _,  _,  _],  # 14 feet
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 15
    ]


# ── BAT ENEMY SPRITE  (16×16 → 32×32) ─────────────────────────────────────────

def bat_sprite():
    """Dark purple bat with spread wings and glowing red eyes."""
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 0
        [_,  BW, _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  BW, _,  _,  _],  # 1  outer wing tips
        [_,  BW, BW, _,  _,  _,  _,  _,  _,  _,  _,  BW, BW, _,  _,  _],  # 2
        [_,  BW, Bw, BW, _,  _,  _,  _,  _,  _,  BW, Bw, BW, _,  _,  _],  # 3
        [_,  BW, Bw, Bw, BW, BB, BB, BB, BB, BW, Bw, Bw, BW, _,  _,  _],  # 4  wings meet body
        [_,  _,  BW, Bw, BB, BE, BB, BB, BE, BB, Bw, BW, _,  _,  _,  _],  # 5  eyes
        [_,  _,  BW, Bw, BB, BB, BB, BB, BB, BB, Bw, BW, _,  _,  _,  _],  # 6  body
        [_,  _,  _,  BW, BB, BB, BB, BB, BB, BB, BW, _,  _,  _,  _,  _],  # 7  lower body
        [_,  _,  _,  _,  BW, Bf, BB, BB, Bf, BW, _,  _,  _,  _,  _,  _],  # 8  belly + feet base
        [_,  _,  _,  _,  _,  Bf, _,  _,  Bf, _,  _,  _,  _,  _,  _,  _],  # 9  claws
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 10
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 11
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 12
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 13
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 14
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 15
    ]


# ── SKELETON KNIGHT ENEMY SPRITE  (16×16 → 32×32) ────────────────────────────
# Armoured melee skeleton: same bone body as Skeleton but with a steel helmet,
# a chest armour plate, and a round shield on its left arm.

# Reuses: SK, SW, SD, Sd from skeleton palette (defined above)
# Extra colours for armour & shield
KA = (110, 115, 130, 255)  # armour steel — cool grey
Ka = ( 70,  75,  88, 255)  # armour shadow
Kh = (170, 175, 190, 255)  # armour highlight
SH = ( 80,  85, 100, 255)  # shield face — dark steel
Sh = (140, 145, 160, 255)  # shield rim / highlight
SB = (180,  50,  50, 255)  # shield emblem — dark red cross
KG = (200, 170,  50, 255)  # gold trim on armour / crest

def skeleton_knight_sprite():
    """
    Skeleton Knight facing forward, heavily armoured.
    Distinguishing features vs. basic skeleton:
      - Steel great-helm covering the skull
      - Chest plate over the ribcage
      - Round shield on the left arm (player's right)
      - Mailed fists instead of bare bone hands
    """
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  _,  KA, KA, KA, KA, KA, KA, _,  _,  _,  _,  _,  _],  # 0  great-helm top
        [_,  _,  _,  Ka, Kh, KA, KA, KA, KA, Kh, Ka, _,  _,  _,  _,  _],  # 1  helm curve
        [_,  _,  _,  Ka, KA, KA, KA, KA, KA, KA, Ka, _,  _,  _,  _,  _],  # 2  helm mid
        [_,  _,  _,  Ka, KA, SD, KA, KA, SD, KA, Ka, _,  _,  _,  _,  _],  # 3  eye slits
        [_,  _,  _,  Ka, KG, KA, KA, KA, KA, KG, Ka, _,  _,  _,  _,  _],  # 4  gold trim band
        [_,  _,  _,  Ka, KA, KA, Sd, Sd, KA, KA, Ka, _,  _,  _,  _,  _],  # 5  visor/jaw guard
        [_,  _,  _,  _,  Ka, KA, KA, KA, KA, Ka, _,  _,  _,  _,  _,  _],  # 6  neck gorget
        [_,  _,  KA, KA, KA, KA, KA, KA, KA, KA, KA, KA, _,  _,  _,  _],  # 7  pauldrons (shoulder plates)
        [SH, Sh, KA, Ka, KA, KA, KA, KA, KA, Ka, SK, SK, _,  _,  _,  _],  # 8  shield arm + chest + sword arm
        [SH, SB, Sh, Ka, KA, KA, KA, KA, SK, _,  _,  SK, _,  _,  _,  _],  # 9  shield face + chest plate
        [SH, SB, Sh, Ka, KA, KA, KA, KA, SK, _,  _,  SK, _,  _,  _,  _],  # 10 shield lower + chest
        [_,  Sh, SH, Ka, KA, KA, KA, KA, KA, Ka, SK, SK, _,  _,  _,  _],  # 11 shield bottom + tassets
        [_,  _,  _,  _,  KA, SK, Sd, Sd, SK, KA, _,  _,  _,  _,  _,  _],  # 12 greaves top
        [_,  _,  _,  _,  _,  SK, _,  _,  SK, _,  _,  _,  _,  _,  _,  _],  # 13 lower legs
        [_,  _,  _,  _,  KA, KA, _,  _,  KA, KA, _,  _,  _,  _,  _,  _],  # 14 sabatons (armoured feet)
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 15
    ]


# ── SKELETON ARCHER ENEMY SPRITE  (16×16 → 32×32) ────────────────────────────
# Ranged skeleton variant: same bone palette as Skeleton but holding a bow
# with an arrow nocked, plus a small brown quiver visible on its back.

# Reuses: SK, SW, SD, Sd from skeleton palette (defined above)
# Extra colours for bow/arrow/quiver
AB = (100,  65,  25, 255)  # bow wood — warm brown
Ab = ( 65,  40,  10, 255)  # bow shadow
AS = (180, 160, 120, 255)  # bow string — light tan
AH = (220, 200,  80, 255)  # arrow head — dull gold
Af = (200, 180, 120, 255)  # arrow shaft
Aw = (220, 215, 200, 255)  # arrow fletching (same as bone, white feather)
QU = ( 90,  55,  20, 255)  # quiver leather — dark brown
Qu = (130,  85,  35, 255)  # quiver highlight

def skeleton_archer_sprite():
    """
    Skeleton Archer facing forward, bow raised to the right side and arrow nocked.
    Distinguishing features vs. basic skeleton:
      - Bow drawn vertically on the right
      - Arrow nocked horizontally across chest
      - Quiver (small brown rectangle) on left shoulder
      - Slightly different arm pose (right arm raised holding bow)
    """
    return [
      # 0   1   2   3   4   5   6   7   8   9  10  11  12  13  14  15
        [_,  _,  _,  _,  _,  SK, SK, SK, SK, _,  _,  _,  _,  _,  _,  _],  # 0  skull top
        [_,  _,  _,  _,  SK, SW, SK, SK, SW, SK, _,  _,  _,  _,  _,  _],  # 1  skull highlights
        [_,  _,  _,  _,  SK, SK, SK, SK, SK, SK, _,  _,  _,  _,  _,  _],  # 2  skull mid
        [_,  _,  _,  _,  SK, SD, SK, SK, SD, SK, _,  _,  _,  _,  _,  _],  # 3  eye sockets
        [_,  _,  _,  _,  SK, SD, SK, SK, SD, SK, _,  _,  _,  _,  _,  _],  # 4  eye sockets
        [_,  _,  _,  _,  SK, SK, Sd, Sd, SK, SK, _,  _,  _,  _,  _,  _],  # 5  jaw
        [_,  _,  _,  _,  _,  SK, SK, SK, SK, _,  _,  _,  _,  _,  _,  _],  # 6  neck
        [_,  QU, SK, SK, SK, SK, SK, SK, SK, SK, SK, AB, _,  _,  _,  _],  # 7  shoulders + quiver + bow tip
        [_,  QU, SK, _,  Sd, SK, SK, SK, SK, Sd, SK, AB, _,  _,  _,  _],  # 8  upper arms + bow
        [AH, Af, Af, Af, Af, SK, SK, SK, SK, _,  _,  AB, AS, _,  _,  _],  # 9  arrow nocked across chest
        [_,  _,  _,  _,  SK, SK, SK, SK, SK, _,  _,  AB, _,  _,  _,  _],  # 10 lower torso + bow
        [_,  _,  _,  _,  SK, SK, SK, SK, SK, SK, _,  Ab, _,  _,  _,  _],  # 11 lower torso
        [_,  _,  _,  _,  _,  SK, Sd, Sd, SK, _,  _,  Ab, _,  _,  _,  _],  # 12 upper legs + bow base
        [_,  _,  _,  _,  _,  SK, _,  _,  SK, _,  _,  _,  _,  _,  _,  _],  # 13 lower legs
        [_,  _,  _,  _,  SK, SK, _,  _,  SK, SK, _,  _,  _,  _,  _,  _],  # 14 feet
        [_,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _,  _],  # 15
    ]


# ── GHOST ENEMY SPRITE  (16×16 → 32×32) ──────────────────────────────────────
# Translucent pale blue-white spirit with hollow dark eyes and a wispy tail.

GW = (210, 230, 255, 220)  # ghost body — pale blue-white, semi-transparent
Gw = (170, 195, 240, 180)  # ghost shadow / shading
GH = (240, 248, 255, 255)  # ghost highlight — near-white
GE = ( 20,  15,  40, 230)  # hollow eye socket — dark navy
Gg = (150, 175, 220, 140)  # ghost wisp — faint fringe / tail
Gx = (100, 130, 200,  90)  # ghost outer glow — very faint blue

def ghost_sprite():
    """
    Hovering ghost facing forward.
    Distinguishing features:
      - Rounded dome head with bright highlight
      - Two large hollow dark eye sockets (no pupils — empty soul)
      - Smooth wide body that tapers into three wispy tail tendrils
      - Semi-transparent palette (alpha < 255) gives an ethereal look
    """
    return [
      # 0    1    2    3    4    5    6    7    8    9   10   11   12   13   14   15
        [_,   _,   _,   _,   _,   Gx,  Gx,  Gx,  Gx,  _,   _,   _,   _,   _,   _,   _  ],  # 0  outer glow top
        [_,   _,   _,   _,   Gw,  GW,  GW,  GW,  GW,  Gw,  _,   _,   _,   _,   _,   _  ],  # 1  head top
        [_,   _,   _,   GW,  GH,  GW,  GW,  GW,  GW,  GW,  GW,  _,   _,   _,   _,   _  ],  # 2  head — highlight left
        [_,   _,   _,   GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  _,   _,   _,   _,   _  ],  # 3  head mid
        [_,   _,   _,   GW,  GE,  GE,  GW,  GW,  GE,  GE,  GW,  _,   _,   _,   _,   _  ],  # 4  eye sockets
        [_,   _,   _,   GW,  GE,  GE,  GW,  GW,  GE,  GE,  GW,  _,   _,   _,   _,   _  ],  # 5  eye sockets
        [_,   _,   _,   GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  _,   _,   _,   _,   _  ],  # 6  lower face
        [_,   _,   Gw,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  Gw,  _,   _,   _,   _  ],  # 7  shoulders wide
        [_,   _,   GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  _,   _,   _,   _  ],  # 8  body upper
        [_,   _,   GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  _,   _,   _,   _  ],  # 9  body mid
        [_,   _,   Gw,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  GW,  Gw,  _,   _,   _,   _  ],  # 10 body lower
        [_,   _,   Gw,  GW,  Gw,  GW,  GW,  GW,  GW,  Gw,  GW,  Gw,  _,   _,   _,   _  ],  # 11 wisp base — three bumps
        [_,   _,   Gg,  GW,  _,   Gg,  GW,  GW,  Gg,  _,   GW,  Gg,  _,   _,   _,   _  ],  # 12 wisp tendrils top
        [_,   _,   Gg,  Gg,  _,   Gg,  Gg,  Gg,  Gg,  _,   Gg,  Gg,  _,   _,   _,   _  ],  # 13 wisp tendrils mid
        [_,   _,   _,   Gg,  _,   _,   Gg,  Gg,  _,   _,   Gg,  _,   _,   _,   _,   _  ],  # 14 wisp tips
        [_,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _  ],  # 15
    ]


# ── LASER SWORD sprite  (16×16 → 32×32) ──────────────────────────────────────
# A glowing energy blade: vivid magenta/violet hilt with a crackling plasma blade.
# Colour palette matches the in-game projectile (magenta-violet energy).

LsB = (200,  60, 255, 255)  # blade — vivid magenta
Lsb = (140,  30, 195, 255)  # blade shadow
LsH = (255, 160, 255, 255)  # blade highlight / hot core
LsG = (220, 100, 255, 128)  # blade outer glow (semi-transparent)
LsK = ( 60,  25,  90, 255)  # hilt — deep purple
Lsk = ( 90,  50, 130, 255)  # hilt highlight
LsC = (255, 220,  80, 255)  # crossguard — gold
Lsc = (180, 150,  40, 255)  # crossguard shadow
LsP = (255, 240, 200, 255)  # plasma tip flash

def laser_sword_sprite():
    """
    Diagonal energy sword (top-right to bottom-left):
      - Pointed plasma blade tip at top-right
      - Glowing blade core with magenta energy
      - Gold crossguard
      - Deep purple wrapped hilt
    """
    return [
      # 0    1    2    3    4    5    6    7    8    9   10   11   12   13   14   15
        [_,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   LsP, LsH, _,   _  ],  # 0  plasma tip
        [_,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   LsH, LsB, LsG, _,   _  ],  # 1
        [_,   _,   _,   _,   _,   _,   _,   _,   _,   _,   LsH, LsB, Lsb, _,   _,   _  ],  # 2
        [_,   _,   _,   _,   _,   _,   _,   _,   _,   LsH, LsB, Lsb, _,   _,   _,   _  ],  # 3
        [_,   _,   _,   _,   _,   _,   _,   _,   LsG, LsB, LsH, _,   _,   _,   _,   _  ],  # 4  blade body
        [_,   _,   _,   _,   _,   _,   _,   LsG, LsB, LsH, _,   _,   _,   _,   _,   _  ],  # 5
        [_,   _,   _,   _,   _,   _,   LsG, LsB, LsH, _,   _,   _,   _,   _,   _,   _  ],  # 6
        [_,   _,   _,   _,   _,   LsC, LsC, LsH, _,   _,   _,   _,   _,   _,   _,   _  ],  # 7  crossguard top
        [_,   _,   _,   _,   LsC, LsC, LsC, LsC, _,   _,   _,   _,   _,   _,   _,   _  ],  # 8  crossguard wide
        [_,   _,   _,   LsC, Lsc, LsC, LsC, _,   _,   _,   _,   _,   _,   _,   _,   _  ],  # 9  crossguard bottom
        [_,   _,   LsK, LsK, Lsk, _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _  ],  # 10 hilt top
        [_,   _,   LsK, Lsk, LsK, _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _  ],  # 11 hilt wrap
        [_,   LsK, LsK, Lsk, _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _  ],  # 12 hilt mid
        [_,   LsK, Lsk, LsK, _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _  ],  # 13 hilt wrap
        [LsK, LsK, Lsk, _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _  ],  # 14 pommel
        [_,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _,   _  ],  # 15
    ]


# ── main ──────────────────────────────────────────────────────────────────────

def generate_all():
    print('Generating sprites...')

    # Wizard player sprites (16×16 → 32×32)
    down_img  = make_image(wizard_down(),  scale=2)
    up_img    = make_image(wizard_up(),    scale=2)
    right_img = make_image(wizard_right(), scale=2)
    left_img  = right_img.transpose(Image.FLIP_LEFT_RIGHT)

    save(down_img,  'player', 'player_down.png')
    save(up_img,    'player', 'player_up.png')
    save(right_img, 'player', 'player_right.png')
    save(left_img,  'player', 'player_left.png')

    # Tile sprites (20×20 → 40×40)
    save(make_image(floor_tile(), scale=2), 'tiles', 'floor.png')
    save(make_image(wall_tile(),  scale=2), 'tiles', 'wall.png')

    # UI sprites
    save(make_image(heart_full(),  scale=2), 'ui', 'heart_full.png')
    save(make_image(heart_empty(), scale=2), 'ui', 'heart_empty.png')
    save(make_image(coin_sprite(), scale=2), 'ui', 'coin.png')

    # Weapon sprites
    save(make_image(lightning_rod_sprite(), scale=2), 'weapons', 'lightning_rod.png')
    save(make_image(laser_sword_sprite(),   scale=2), 'weapons', 'laser_sword.png')

    # Enemy sprites
    save(make_image(skeleton_sprite(),        scale=2), 'enemies', 'skeleton.png')
    save(make_image(skeleton_archer_sprite(), scale=2), 'enemies', 'skeleton_archer.png')
    save(make_image(skeleton_knight_sprite(), scale=2), 'enemies', 'skeleton_knight.png')
    save(make_image(zombie_sprite(),          scale=2), 'enemies', 'zombie.png')
    save(make_image(bat_sprite(),             scale=2), 'enemies', 'bat.png')
    save(make_image(ghost_sprite(),           scale=2), 'enemies', 'ghost.png')

    print('All sprites generated!')


if __name__ == '__main__':
    generate_all()
