"""
game.py — Main game loop, state machine, and rendering.

States
------
  main_menu    Title screen (Phase 7)
  playing      Normal gameplay
  shopping     Shop menu open (game paused)
  quizzing     Quiz Master mini-game overlay
  fading_out   Black fade when player exits a room
  fading_in    Black fade clearing after room switch
  game_over    Player died
  victory      Final boss beaten  (Phase 6)

Phase 5:  shopping state, shopkeeper NPC, shop menu
Phase 6:  dragon + skeleton king bosses, victory screen
Phase 7:  main menu, sound effects, visited-room minimap
"""

import asyncio
import pygame
import math
import random

from settings   import (WINDOW_WIDTH, WINDOW_HEIGHT, FPS,
                        TITLE, TILE_SIZE, ROOM_COLS, ROOM_ROWS, ROOM_OFFSET_Y,
                        WEAPON_DISPLAY_NAMES, PLAYER_MAX_HEARTS)
from player     import Player
from dungeon    import Dungeon
from ui         import HUD
from shop       import Shopkeeper, ShopMenu
from sounds     import SoundManager
from quiz       import QuizMaster, QuizMenu
from bombs      import Bomb, BOMB_RADIUS, BOMB_DAMAGE

# ── Transition constants ──────────────────────────────────────────────────────

FADE_STEP          = 24
TITLE_SHOW_FRAMES  = 160

# ── Where the player re-appears after passing through a door ──────────────────

_CX  = ROOM_COLS  // 2 * TILE_SIZE
_CY  = ROOM_OFFSET_Y + ROOM_ROWS // 2 * TILE_SIZE
_M   = 2 * TILE_SIZE + TILE_SIZE // 2

ENTRY_POS = {
    'N': (_CX, ROOM_OFFSET_Y + _M),
    'S': (_CX, ROOM_OFFSET_Y + ROOM_ROWS * TILE_SIZE - _M),
    'W': (_M,  _CY),
    'E': (ROOM_COLS * TILE_SIZE - _M, _CY),
}

ENTRY_FACING = {
    'N': 'down',
    'S': 'up',
    'W': 'right',
    'E': 'left',
}

# ── Pickup pop-up notification ────────────────────────────────────────────────
NOTIFY_FRAMES = 120


class Game:

    def __init__(self):
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        pygame.display.set_caption(TITLE)
        self.clock = pygame.time.Clock()
        pygame.font.init()

        self.font_big    = pygame.font.SysFont('Arial', 64, bold=True)
        self.font_med    = pygame.font.SysFont('Arial', 28)
        self.font_title  = pygame.font.SysFont('Georgia', 22, italic=True)
        self.font_notify = pygame.font.SysFont('Georgia', 20, italic=True)
        self.font_small  = pygame.font.SysFont('Arial', 14)

        self._black = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        self._black.fill((0, 0, 0))

        # Sound effects — generated once at startup
        self.sfx = SoundManager()

        # Shop objects are created once and reused across restarts
        self.shopkeeper = Shopkeeper()
        self.shop_menu  = ShopMenu()

        # Title-screen blink state
        self._menu_blink  = 0
        self._menu_blink_on = True

        self._new_game()

    # ── initialise / reset ────────────────────────────────────────────────────

    def _new_game(self):
        self.dungeon = Dungeon()
        self.player  = Player(ROOM_COLS // 2, ROOM_ROWS // 2)
        self.hud     = HUD()

        self.projectiles       = pygame.sprite.Group()
        self.enemy_projectiles = pygame.sprite.Group()

        self.state       = 'main_menu'
        self.fade_alpha  = 0
        self._exit_dir   = None

        # Minimap — track which rooms the player has visited
        self.visited_rooms = {self.dungeon.current_id}

        self.title_timer = TITLE_SHOW_FRAMES

        self._notify_text  = ''
        self._notify_timer = 0

        # Re-create shopkeeper so his stock resets too
        self.shopkeeper = Shopkeeper()

        # Quiz Master (quiz_room)
        self.quiz_master = QuizMaster()
        self.quiz_menu   = QuizMenu()

        # Active bombs placed in the world
        self.bombs = []

        # Cooldown to avoid spamming mystery-door blocked messages
        self._key_door_blocked_timer = 0

        # Track E-key state for one-shot detection
        self._e_was_down = False

        # Track B-key state for bomb placement
        self._b_was_down = False

        # Mega Bow explosion visual effects list — each entry: {cx, cy, timer}
        self._explosion_fx = []

        # Boss room enter fanfare
        self._fanfare_timer    = 0    # counts down; enemies frozen while > 0
        self._shake_frames     = 0    # screen shake counter
        FANFARE_FREEZE_FRAMES  = 90   # 1.5 s freeze
        SHAKE_FRAMES           = 30   # 0.5 s shake
        self._boss_rooms_seen  = set()  # don't re-trigger on re-entry

        # Roll tutorial hint — shown in start room until player rolls or leaves
        self._roll_hint_active = True   # turned off once player rolls or moves on
        self._roll_hint_blink  = 0      # frame counter for blink animation

    # ── main loop ─────────────────────────────────────────────────────────────

    async def run(self):
        self._running = True
        while self._running:
            self.clock.tick(FPS)
            self._handle_events()

            {
                'main_menu':  self._update_main_menu,
                'playing':    self._update_playing,
                'shopping':   self._update_shopping,
                'quizzing':   self._update_quizzing,
                'controls':   lambda: None,
                'fading_out': self._update_fade_out,
                'fading_in':  self._update_fade_in,
                'game_over':  lambda: None,
                'victory':    lambda: None,
            }.get(self.state, lambda: None)()

            self._draw()
            pygame.display.flip()
            await asyncio.sleep(0)   # yield control to the browser each frame

    # ── event handling ────────────────────────────────────────────────────────

    def _handle_events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self._running = False
                return

            if event.type == pygame.KEYDOWN:
                # ESC: close shop/quiz/controls if open, otherwise quit
                if event.key == pygame.K_ESCAPE:
                    if self.state == 'shopping':
                        self.state = 'playing'
                    elif self.state == 'quizzing':
                        self.state = 'playing'
                    elif self.state == 'controls':
                        self.state = 'playing'
                    else:
                        self._running = False
                        return

                # TAB: toggle controls overlay during play (or close it)
                if event.key == pygame.K_TAB:
                    if self.state == 'playing':
                        self.state = 'controls'
                    elif self.state == 'controls':
                        self.state = 'playing'

                # ENTER / SPACE on main menu → start game
                if event.key in (pygame.K_RETURN, pygame.K_SPACE) and self.state == 'main_menu':
                    self.sfx.play('menu_start')
                    self.state = 'playing'

                # R on game-over / victory → return to main menu
                if event.key == pygame.K_r and self.state in ('game_over', 'victory'):
                    self._new_game()

    # ── update helpers ────────────────────────────────────────────────────────

    def _update_playing(self):
        room = self.dungeon.current_room

        # Tick boss fanfare — enemies frozen during this window
        if self._fanfare_timer > 0:
            self._fanfare_timer -= 1
        if self._shake_frames  > 0:
            self._shake_frames  -= 1

        self.player.update(room.wall_rects)

        # Dismiss roll tutorial hint once player rolls or leaves start room
        if self._roll_hint_active:
            if self.player.is_rolling or self.dungeon.current_id != 'start':
                self._roll_hint_active = False
            else:
                self._roll_hint_blink = (self._roll_hint_blink + 1) % 80

        if self.player.is_dead:
            if self.player.has_potion:
                # Revive! Consume the potion and restore 3 hearts
                self.player.has_potion = False
                self.player.hearts     = min(3.0, float(self.player.max_hearts))
                self.player.inv_frames = 120   # 2 s of i-frames so player can react
                self._notify('The potion saved you!  Back from the brink...')
                self.sfx.play('victory')      # triumphant sting on revive
            else:
                self.state = 'game_over'
                self.sfx.play('game_over')
                return

        keys = pygame.key.get_pressed()

        e_down = keys[pygame.K_e]

        # ── Mystery-key door interaction ───────────────────────────────────────
        if self._key_door_blocked_timer > 0:
            self._key_door_blocked_timer -= 1
        room_obj = self.dungeon.current_room
        for mdir in list(room_obj.mystery_locked_doors):
            dx, dy = room_obj.mystery_door_screen_pos(mdir)
            px, py = self.player.hitbox.center
            if math.hypot(px - dx, py - dy) < 2.5 * TILE_SIZE:
                # Near enough: E presses the door
                if e_down and not self._e_was_down:
                    if self.player.mystery_keys > 0:
                        self.player.mystery_keys -= 1
                        self.dungeon.unlock_mystery_door(self.dungeon.current_id, mdir)
                        self._notify('Mystery Key used!  The passage opens...')
                        self.sfx.play('door_unlock')
                    elif self._key_door_blocked_timer <= 0:
                        self._notify('A locked door.  You need a Mystery Key!')
                        self._key_door_blocked_timer = 120

        # ── Shopkeeper interaction (shop room only) ────────────────────────────
        if self.dungeon.current_type == 'shop':
            self.shopkeeper.update()
            if e_down and not self._e_was_down:
                if self.shopkeeper.player_in_range(self.player.hitbox):
                    self.shop_menu.open(self.player)
                    self.state = 'shopping'
                    self._e_was_down = e_down
                    return   # skip the rest of this frame

        # ── Quiz Master interaction (quiz room only) ───────────────────────────
        elif self.dungeon.current_type == 'quiz':
            self.quiz_master.update()
            if e_down and not self._e_was_down:
                if self.quiz_master.player_in_range(self.player.hitbox):
                    if not self.quiz_menu.bombs_given:
                        self.quiz_menu.open()
                        self.state = 'quizzing'
                        self._e_was_down = e_down
                        return

        # ── Chest interaction (any room with chests) ──────────────────────────
        if e_down and not self._e_was_down:
            for chest in room.chests:
                if chest.can_interact(self.player.hitbox):
                    if self.player.chest_keys > 0:
                        if chest.open(room, self.player):
                            self._notify('Chest opened!')
                            self.sfx.play('coin')
                    else:
                        self._notify('You need a Chest Key to open this!')
                    break

        self._e_was_down = e_down

        # ── Attack: fire projectile(s) ────────────────────────────────────────
        new_projs = self.player.try_fire()
        if new_projs:
            self.sfx.play('fire')
        for p in new_projs:
            # Ice sword bolts home toward enemies — give them the live enemy group
            if p._weapon == 'ice_sword':
                p.home_targets = room.enemies
            self.projectiles.add(p)

        # ── Update projectiles ────────────────────────────────────────────────
        for p in list(self.projectiles):
            was_alive = p.alive()
            p.update(room.wall_rects)
            # Mega Bow: trigger explosion when the arrow hits a wall (killed in update)
            if was_alive and not p.alive() and p.is_explosive:
                self._mega_bow_explode(p.rect.center, room)

        # ── Update enemies + contact / projectile damage ──────────────────────
        # Skip enemy AI during boss-room fanfare freeze
        if self._fanfare_timer > 0:
            # Still let projectile collision run so existing bolts can hit
            for p in list(self.projectiles):
                p.update(room.wall_rects)
            # Don't process enemy AI this frame
            if self._notify_timer > 0: self._notify_timer -= 1
            if self.title_timer   > 0: self.title_timer   -= 1
            exit_dir = room.check_exit(self.player.hitbox)
            if exit_dir:
                self._exit_dir = exit_dir
                self.state     = 'fading_out'
            return

        for enemy in list(room.enemies):
            fired = enemy.update(self.player, room.wall_rects)
            if fired is not None:
                # Dragon returns a list; regular enemies return a single projectile
                if isinstance(fired, list):
                    for f in fired:
                        self.enemy_projectiles.add(f)
                else:
                    self.enemy_projectiles.add(fired)

            # Drain pending skeleton spawns (SkeletonKing phase 2)
            if enemy.pending_spawns:
                for spawn in enemy.pending_spawns:
                    room.enemies.add(spawn)
                enemy.pending_spawns.clear()

            old_inv = self.player.inv_frames
            enemy.try_damage_player(self.player)
            if self.player.inv_frames > old_inv:
                self.sfx.play('player_hurt')

            for p in list(self.projectiles):
                if p.alive() and p.hitbox.colliderect(enemy.hitbox):
                    # Skeleton Knight shield block — deflects frontal projectiles
                    from enemy import SkeletonKnight as _SK
                    if isinstance(enemy, _SK) and enemy.blocks_projectile(p.hitbox):
                        # Shield deflection: projectile dies, play hit sound, no damage
                        self.sfx.play('hit_enemy')
                        p.kill()
                    else:
                        if enemy.take_hit(p.damage):
                            self.sfx.play('hit_enemy')
                        if p.is_explosive:
                            self._mega_bow_explode(p.rect.center, room)
                        p.kill()

            if enemy.is_dead:
                ex, ey = enemy.hitbox.center
                if enemy.is_boss:
                    # Bosses always drop their full coin reward
                    room.spawn_coin_drop(ex, ey, enemy.coin_drop)
                    self._on_boss_death(enemy.boss_type)
                else:
                    # Regular enemies: 5% chest key, 20% heart, else coins
                    roll = random.random()
                    if roll < 0.05:
                        from pickups import ChestKeyPickup
                        room.chest_key_pickups.add(ChestKeyPickup(ex, ey))
                    elif roll < 0.25:
                        room.spawn_heart_drop(ex, ey)
                    else:
                        room.spawn_coin_drop(ex, ey, enemy.coin_drop)
                enemy.kill()

        # ── Update enemy projectiles ──────────────────────────────────────────
        for ep in list(self.enemy_projectiles):
            ep.update(room.wall_rects)
            if ep.alive() and ep.hitbox.colliderect(self.player.hitbox):
                if self.player.take_damage(ep.damage):
                    self.sfx.play('player_hurt')
                ep.kill()

        # ── Update weapon pickups ─────────────────────────────────────────────
        for wp in list(room.weapon_pickups):
            wp.update()
            if not wp.collected and wp.hitbox.colliderect(self.player.hitbox):
                if not self.player.has_weapon(wp.weapon_key):
                    self.player.add_weapon(wp.weapon_key)
                    name = WEAPON_DISPLAY_NAMES.get(wp.weapon_key, wp.weapon_key.title())
                    self._notify(f'Got the {name}!  Press Q to switch weapons')
                    self.sfx.play('weapon_pickup')
                wp.collected = True
                wp.kill()

        # ── Update coin pickups (+ magnet effect while rolling) ──────────────
        MAGNET_SPEED  = 8   # px/frame pull toward player
        MAGNET_RADIUS = 5 * TILE_SIZE  # only attract coins within this range
        rolling = self.player.is_rolling
        px, py  = self.player.hitbox.center

        for cp in list(room.coin_pickups):
            cp.update()

            # Coin magnet: while rolling, pull nearby coins toward the player
            if rolling and not cp.collected:
                cx2, cy2 = cp.hitbox.center
                dist = math.hypot(px - cx2, py - cy2)
                if 0 < dist < MAGNET_RADIUS:
                    mx = int((px - cx2) / dist * MAGNET_SPEED)
                    my = int((py - cy2) / dist * MAGNET_SPEED)
                    cp.rect.x    += mx
                    cp.rect.y    += my
                    cp.hitbox.x  += mx
                    cp.hitbox.y  += my

            if not cp.collected and cp.hitbox.colliderect(self.player.hitbox):
                self.player.coins += cp.value
                self.sfx.play('coin')
                cp.collected = True
                cp.kill()

        # ── Update heart pickups ──────────────────────────────────────────────
        for hp in list(room.heart_pickups):
            hp.update()
            if not hp.collected and hp.hitbox.colliderect(self.player.hitbox):
                # Only collect when the player actually needs healing
                if self.player.hearts < self.player.max_hearts:
                    self.player.hearts = min(self.player.hearts + 1,
                                             self.player.max_hearts)
                    self.sfx.play('coin')
                    hp.collected = True
                    hp.kill()
                # At full health, the heart stays on the floor

        # ── Update heart container pickups ────────────────────────────────────
        for hcp in list(room.heart_container_pickups):
            hcp.update()
            if not hcp.collected and hcp.hitbox.colliderect(self.player.hitbox):
                if self.player.max_hearts < PLAYER_MAX_HEARTS:
                    self.player.max_hearts = min(self.player.max_hearts + 1,
                                                 PLAYER_MAX_HEARTS)
                    self.player.hearts = min(self.player.hearts + 1,
                                             self.player.max_hearts)
                    self._notify('Heart Container found!  Max hearts increased!')
                    self.sfx.play('weapon_pickup')
                hcp.collected = True
                hcp.kill()

        # ── Update chest key pickups ──────────────────────────────────────────
        for ck in list(room.chest_key_pickups):
            ck.update()
            if not ck.collected and ck.hitbox.colliderect(self.player.hitbox):
                self.player.chest_keys += 1
                self.sfx.play('coin')
                self._notify(f'Chest Key found!  Keys: {self.player.chest_keys}')
                ck.collected = True
                ck.kill()

        # ── Update chests ─────────────────────────────────────────────────────
        for chest in room.chests:
            chest.update()

        # ── Update bomb pickups ───────────────────────────────────────────────
        for bp in list(room.bomb_pickups):
            bp.update()
            if not bp.collected and bp.hitbox.colliderect(self.player.hitbox):
                from pickups import BombPickup as _BP
                self.player.bombs += _BP.AMOUNT
                self.sfx.play('weapon_pickup')
                self._notify(f'+{_BP.AMOUNT} Bombs!  Press B to plant one.')
                bp.collected = True
                bp.kill()

        # ── Bomb placement (B key) ────────────────────────────────────────────
        b_down = keys[pygame.K_b]
        if b_down and not self._b_was_down:
            if self.player.bombs > 0:
                bx, by = self.player.hitbox.center
                self.bombs.append(Bomb(bx, by))
                self.player.bombs -= 1
                self._notify('Bomb planted!')
        self._b_was_down = b_down

        # ── Update bombs & apply explosion damage ─────────────────────────────
        for bomb in list(self.bombs):
            exploded_this_frame = bomb.update()
            if exploded_this_frame:
                # Damage enemies in blast radius
                for enemy in list(room.enemies):
                    if bomb.in_blast(enemy.hitbox):
                        enemy.take_hit(BOMB_DAMAGE)
                        enemy.flash_frames = 15
                # Damage player if in blast radius
                if bomb.in_blast(self.player.hitbox):
                    self.player.take_damage(BOMB_DAMAGE)
                    self.sfx.play('player_hurt')
                self.sfx.play('boss_death')   # reuse big-impact sound for explosion

                # ── Check if blast reveals a bomb-locked secret passage ────────
                for b_dir in list(room.bomb_locked_doors):
                    wall_pos = self._bomb_door_wall_pos(b_dir)
                    if wall_pos and math.hypot(bomb.x - wall_pos[0],
                                               bomb.y - wall_pos[1]) <= BOMB_RADIUS:
                        self.dungeon.unlock_bomb_door(self.dungeon.current_id, b_dir)
                        self._notify('A secret passage has been revealed!')
                        self.sfx.play('door_unlock')

            if bomb.done:
                self.bombs.remove(bomb)

        # Tick banners
        if self.title_timer   > 0: self.title_timer   -= 1
        if self._notify_timer > 0: self._notify_timer -= 1

        # Check if player walked through a door
        exit_dir = room.check_exit(self.player.hitbox)
        if exit_dir:
            self._exit_dir = exit_dir
            self.state     = 'fading_out'

    def _update_main_menu(self):
        """Tick the blinking 'Press ENTER' text.  Input handled in _handle_events."""
        self._menu_blink += 1
        if self._menu_blink >= 40:
            self._menu_blink    = 0
            self._menu_blink_on = not self._menu_blink_on

    def _update_shopping(self):
        """Process shop menu input while the game is paused."""
        keys  = pygame.key.get_pressed()
        close = self.shop_menu.update(keys)

        # Play sound signals emitted by the shop menu
        ev = self.shop_menu.sound_event
        if   ev == 'move': self.sfx.play('menu_move')
        elif ev == 'buy':  self.sfx.play('menu_confirm')
        elif ev == 'fail': self.sfx.play('player_hurt')

        if close:
            self.state = 'playing'

    def _update_quizzing(self):
        """Process Quiz Master input while the game is paused."""
        keys  = pygame.key.get_pressed()
        close = self.quiz_menu.update(keys)

        ev = self.quiz_menu.sound_event
        if ev == 'correct':
            self.sfx.play('menu_confirm')
        elif ev == 'wrong':
            self.sfx.play('player_hurt')

        if close:
            # Award bombs if just passed and not yet rewarded
            if self.quiz_menu.passed and not self.quiz_menu.bombs_given:
                self.player.bombs += 3
                self.quiz_menu.bombs_given = True
                self._notify('You got 3 BOMBS!  Press B to place one.')
            self.state = 'playing'

    def _update_fade_out(self):
        self.fade_alpha = min(255, self.fade_alpha + FADE_STEP)
        if self.fade_alpha >= 255:
            self._do_room_switch()
            self.state = 'fading_in'

    def _update_fade_in(self):
        self.fade_alpha = max(0, self.fade_alpha - FADE_STEP)
        if self.fade_alpha <= 0:
            self.state = 'playing'

    def _do_room_switch(self):
        entry_dir = self.dungeon.go(self._exit_dir)
        if entry_dir is None:
            return

        x, y = ENTRY_POS[entry_dir]
        self.player.hitbox.center = (x, y)
        self.player.rect.center   = (x, y)
        self.player.direction     = ENTRY_FACING[entry_dir]
        self.player.inv_frames    = 0

        self.projectiles.empty()
        self.enemy_projectiles.empty()

        self.title_timer = TITLE_SHOW_FRAMES

        # Boss fanfare — trigger once per boss room per game session
        new_id   = self.dungeon.current_id
        new_type = self.dungeon.current_type
        if new_type in ('mini_boss', 'boss') and new_id not in self._boss_rooms_seen:
            self._boss_rooms_seen.add(new_id)
            FANFARE_FREEZE_FRAMES = 90
            SHAKE_FRAMES          = 30
            self._fanfare_timer   = FANFARE_FREEZE_FRAMES
            self._shake_frames    = SHAKE_FRAMES
            self.sfx.play('boss_death')   # dramatic boom (reuse impact sound)

        # Mark new room as visited for the minimap
        self.visited_rooms.add(self.dungeon.current_id)

    def _bomb_door_wall_pos(self, direction):
        """
        Return the approximate screen (x, y) of a bomb-locked wall face
        so we can check whether a bomb blast is close enough to break it open.
        The position is the mid-point of the door gap on the wall's inner face.
        """
        from settings import ROOM_COLS, ROOM_ROWS, ROOM_OFFSET_X, ROOM_OFFSET_Y
        cx = ROOM_OFFSET_X + ROOM_COLS // 2 * TILE_SIZE   # horizontal centre
        cy = ROOM_OFFSET_Y + ROOM_ROWS // 2 * TILE_SIZE   # vertical centre
        if direction == 'N':
            return (cx, ROOM_OFFSET_Y + 2 * TILE_SIZE)
        if direction == 'S':
            return (cx, ROOM_OFFSET_Y + (ROOM_ROWS - 2) * TILE_SIZE)
        if direction == 'W':
            return (ROOM_OFFSET_X + 2 * TILE_SIZE, cy)
        if direction == 'E':
            return (ROOM_OFFSET_X + (ROOM_COLS - 2) * TILE_SIZE, cy)
        return None

    # ── Mega Bow explosion ────────────────────────────────────────────────────

    _EXPLOSION_RADIUS = 3 * 40   # 3 tiles (TILE_SIZE = 40)
    _EXPLOSION_DAMAGE = 4        # AOE damage dealt to each enemy in radius

    def _mega_bow_explode(self, center, room):
        """
        Trigger a Mega Bow AOE blast centred at `center` (pixel coords).
        All enemies within _EXPLOSION_RADIUS pixels take _EXPLOSION_DAMAGE.
        A visual flash ring is drawn on the next frame via _explosion_fx.
        """
        ex, ey = center
        for enemy in list(room.enemies):
            if not enemy.alive():
                continue
            ecx, ecy = enemy.hitbox.center
            if math.hypot(ecx - ex, ecy - ey) <= self._EXPLOSION_RADIUS:
                if enemy.take_hit(self._EXPLOSION_DAMAGE):
                    self.sfx.play('hit_enemy')
        # Queue a visual explosion effect (drawn in _draw_playing)
        self._explosion_fx.append({'cx': ex, 'cy': ey, 'timer': 18})

    def _notify(self, text):
        self._notify_text  = text
        self._notify_timer = NOTIFY_FRAMES

    def _on_boss_death(self, boss_type):
        """Handle boss-specific death consequences."""
        self.sfx.play('boss_death')
        if boss_type == 'dragon':
            # Unlock the south door (to bat cave) and east door (to Dragon's Hoard)
            self.dungeon.unlock_door('dragon_room', 'S')
            self.dungeon.unlock_door('dragon_room', 'E')
            self._notify("The Dragon falls! Two passages open...")
            self.sfx.play('door_unlock')
        elif boss_type == 'skeleton_king':
            # Victory!
            self.state = 'victory'
            self.sfx.play('victory')

    # ── drawing ───────────────────────────────────────────────────────────────

    def _draw_mystery_door_prompts_to(self, surface):
        """
        For each mystery-locked door in the current room, show a floating
        prompt near the door when the player is within 2.5 tiles.

          • '[E]  Use Mystery Key'       — if player owns at least one key
          • 'Locked — Need a Mystery Key' — if player has no keys
        """
        room = self.dungeon.current_room
        if not room.mystery_locked_doors:
            return

        px, py = self.player.hitbox.center

        for mdir in room.mystery_locked_doors:
            dx, dy = room.mystery_door_screen_pos(mdir)
            if math.hypot(px - dx, py - dy) >= 2.5 * TILE_SIZE:
                continue

            # Close enough — choose prompt text
            if self.player.mystery_keys > 0:
                text  = '[E]  Use Mystery Key'
                color = (160, 230, 110)
            else:
                text  = 'Door is locked.'
                color = (230, 90, 70)

            surf = self.font_small.render(text, True, color)
            rect = surf.get_rect(centerx=dx, bottom=dy - 10)

            # Semi-transparent backdrop for readability
            pad = 5
            bg  = pygame.Surface(
                (surf.get_width() + pad * 2, surf.get_height() + pad * 2),
                pygame.SRCALPHA,
            )
            bg.fill((0, 0, 0, 150))
            surface.blit(bg, (rect.left - pad, rect.top - pad))
            surface.blit(surf, rect)

    def _draw(self):
        # Main menu gets its own full-screen draw; skip the game world
        if self.state == 'main_menu':
            self._draw_main_menu()
            return

        # Screen shake: render world to an offscreen surface, then blit with offset
        if self._shake_frames > 0:
            shake_x = random.randint(-4, 4)
            shake_y = random.randint(-4, 4)
            canvas = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT))
        else:
            shake_x = shake_y = 0
            canvas = self.screen

        canvas.fill((10, 8, 6))

        room = self.dungeon.current_room
        room.draw(canvas)

        # Coin pickups
        for cp in room.coin_pickups:
            cp.draw(canvas)

        # Heart pickups
        for hp in room.heart_pickups:
            hp.draw(canvas)

        # Heart container pickups
        for hcp in room.heart_container_pickups:
            hcp.draw(canvas)

        # Chest key pickups
        for ck in room.chest_key_pickups:
            ck.draw(canvas)

        # Chests
        for chest in room.chests:
            chest.draw(canvas)
            if chest.can_interact(self.player.hitbox):
                chest.draw_prompt(canvas, self.font_small)

        # Bomb pickups
        for bp in room.bomb_pickups:
            bp.draw(canvas)

        # Weapon pickups
        for wp in room.weapon_pickups:
            wp.draw(canvas)
            wp.draw_label(canvas, self.font_small)

        # Shopkeeper (shop room only)
        if self.dungeon.current_type == 'shop':
            self.shopkeeper.draw(canvas, self.player.hitbox, self.font_small)

        # Quiz Master (quiz room only)
        if self.dungeon.current_type == 'quiz':
            self.quiz_master.draw(canvas, self.player.hitbox, self.font_small,
                                  self.quiz_menu.bombs_given)

        # Mystery-door key prompt (any room that still has mystery locked doors)
        self._draw_mystery_door_prompts_to(canvas)

        # Enemies
        for enemy in room.enemies:
            enemy.draw(canvas)

        self.player.draw(canvas)

        # Projectiles
        for proj in self.projectiles:
            proj.draw(canvas)
        for ep in self.enemy_projectiles:
            ep.draw(canvas)

        # Mega Bow explosion visual rings
        still_active = []
        for fx in self._explosion_fx:
            fx['timer'] -= 1
            if fx['timer'] > 0:
                progress = 1.0 - fx['timer'] / 18.0   # 0→1 as it expands
                radius   = int(self._EXPLOSION_RADIUS * progress)
                alpha    = max(0, int(220 * (1.0 - progress)))
                if radius > 0:
                    ring_surf = pygame.Surface((radius * 2 + 4, radius * 2 + 4), pygame.SRCALPHA)
                    pygame.draw.circle(ring_surf, (255, 180, 30, alpha),
                                       (radius + 2, radius + 2), radius, 4)
                    pygame.draw.circle(ring_surf, (255, 240, 100, alpha // 2),
                                       (radius + 2, radius + 2), max(1, radius - 6), 2)
                    canvas.blit(ring_surf, (fx['cx'] - radius - 2, fx['cy'] - radius - 2))
                still_active.append(fx)
        self._explosion_fx = still_active

        # Bombs (drawn on top of projectiles but below HUD)
        for bomb in self.bombs:
            bomb.draw(canvas)

        self.hud.draw(canvas, self.player)
        self.hud.draw_minimap(canvas, self.dungeon, self.visited_rooms)

        # Boss health bar — shown whenever a boss is alive in the room
        for enemy in room.enemies:
            if enemy.is_boss:
                self.hud.draw_boss_bar(canvas, enemy)
                break

        self._draw_room_title_to(canvas)
        self._draw_notify_to(canvas)
        self._draw_roll_hint_to(canvas)

        # Boss fanfare flash overlay (white flash on freeze entry)
        if self._fanfare_timer > 0:
            FANFARE_FREEZE_FRAMES = 90
            t_left = self._fanfare_timer
            if t_left > FANFARE_FREEZE_FRAMES - 12:
                alpha = int(200 * (FANFARE_FREEZE_FRAMES - t_left) / 12)
                flash = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
                flash.fill((255, 255, 255, max(0, 200 - alpha * 16)))
                canvas.blit(flash, (0, 0))

        if self.fade_alpha > 0:
            self._black.set_alpha(self.fade_alpha)
            canvas.blit(self._black, (0, 0))

        # Shop menu drawn on top of everything
        if self.state == 'shopping':
            self.shop_menu.draw(canvas)

        # Quiz menu drawn on top of everything
        if self.state == 'quizzing':
            self.quiz_menu.draw(canvas)

        # Controls overlay — drawn on top of game world
        if self.state == 'controls':
            self._draw_controls_screen(canvas)

        if self.state == 'game_over':
            self._draw_overlay_to(canvas, 'GAME OVER', (200, 50, 50),
                                  'Press R to restart   |   ESC to quit')
        elif self.state == 'victory':
            self._draw_overlay_to(canvas, 'YOU WIN!',  (80, 200, 80),
                                  'Press R to play again   |   ESC to quit')

        # If shaking, blit canvas at offset; otherwise canvas IS self.screen already
        if self._shake_frames > 0:
            self.screen.fill((0, 0, 0))
            self.screen.blit(canvas, (shake_x, shake_y))

    def _draw_room_title_to(self, surface):
        if self.title_timer <= 0:
            return
        t = self.title_timer
        if   t > TITLE_SHOW_FRAMES - 30: alpha = int(255 * (TITLE_SHOW_FRAMES - t) / 30)
        elif t < 30:                     alpha = int(255 * t / 30)
        else:                            alpha = 255

        surf = self.font_title.render(self.dungeon.current_title, True, (225, 200, 140))
        surf.set_alpha(alpha)
        rect = surf.get_rect(centerx=WINDOW_WIDTH // 2, top=ROOM_OFFSET_Y + 10)
        surface.blit(surf, rect)

    def _draw_notify_to(self, surface):
        if self._notify_timer <= 0:
            return
        t     = self._notify_timer
        alpha = 255 if t > 30 else int(255 * t / 30)
        surf  = self.font_notify.render(self._notify_text, True, (120, 255, 140))
        surf.set_alpha(alpha)
        rect  = surf.get_rect(centerx=WINDOW_WIDTH // 2,
                              bottom=ROOM_OFFSET_Y - 6)
        # Dark backdrop for readability
        pad = 6
        bg = pygame.Surface((surf.get_width() + pad * 2, surf.get_height() + pad * 2),
                            pygame.SRCALPHA)
        bg_alpha = min(200, alpha)
        bg.fill((0, 0, 0, bg_alpha))
        surface.blit(bg, (rect.left - pad, rect.top - pad))
        surface.blit(surf, rect)

    def _draw_roll_hint_to(self, surface):
        """
        Blinking tutorial prompt shown only in the start room until the player
        rolls for the first time.  Fades in/out on a slow sine cycle.
        """
        if not self._roll_hint_active:
            return

        import math as _math
        # Smooth sine-wave alpha: 0 → 255 → 0 over 80-frame cycle
        alpha = int(255 * (_math.sin(_math.pi * self._roll_hint_blink / 80)) ** 2)
        if alpha < 10:
            return

        font  = pygame.font.SysFont('Arial', 15, bold=True)
        line1 = font.render('Tip:  Press  [Left Alt]  to  Roll-Dodge!', True, (140, 230, 255))
        line2 = self.font_small.render('Rolling gives you i-frames and pulls nearby coins toward you.',
                                       True, (160, 200, 200))

        # Position: just below the room, centred
        cx    = WINDOW_WIDTH // 2
        y_bot = WINDOW_HEIGHT - 14           # just above bottom edge
        y1    = y_bot - line1.get_height() - line2.get_height() - 4
        y2    = y1 + line1.get_height() + 4

        # Backdrop pill
        w   = max(line1.get_width(), line2.get_width()) + 24
        h   = line1.get_height() + line2.get_height() + 16
        bg  = pygame.Surface((w, h), pygame.SRCALPHA)
        bg.fill((0, 0, 0, min(180, alpha)))
        pygame.draw.rect(bg, (60, 160, 200, min(200, alpha)), (0, 0, w, h), 1, border_radius=6)
        surface.blit(bg, (cx - w//2, y1 - 6))

        line1.set_alpha(alpha)
        line2.set_alpha(alpha)
        surface.blit(line1, line1.get_rect(centerx=cx, top=y1))
        surface.blit(line2, line2.get_rect(centerx=cx, top=y2))

    def _draw_overlay_to(self, surface, headline, color, subtext):
        overlay = pygame.Surface((WINDOW_WIDTH, WINDOW_HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        surface.blit(overlay, (0, 0))

        h1 = self.font_big.render(headline, True, color)
        h2 = self.font_med.render(subtext,  True, (220, 220, 220))
        surface.blit(h1, h1.get_rect(center=(WINDOW_WIDTH // 2,
                                              WINDOW_HEIGHT // 2 - 40)))
        surface.blit(h2, h2.get_rect(center=(WINDOW_WIDTH // 2,
                                              WINDOW_HEIGHT // 2 + 30)))

    def _draw_controls_screen(self, surface):
        """
        Full-screen controls & stats overlay shown when state == 'controls'.
        The game world is still drawn underneath for atmosphere.
        Press TAB or ESC to close.
        """
        W, H = WINDOW_WIDTH, WINDOW_HEIGHT

        # ── Semi-transparent dark backdrop ───────────────────────────────────
        overlay = pygame.Surface((W, H), pygame.SRCALPHA)
        overlay.fill((8, 5, 3, 210))
        surface.blit(overlay, (0, 0))

        # ── Decorative border ─────────────────────────────────────────────────
        PAD = 18
        pygame.draw.rect(surface, (110, 85, 45),
                         (PAD, PAD, W - 2*PAD, H - 2*PAD), 2, border_radius=6)
        pygame.draw.rect(surface, (60, 46, 28),
                         (PAD+4, PAD+4, W - 2*(PAD+4), H - 2*(PAD+4)), 1, border_radius=4)

        # ── Title ─────────────────────────────────────────────────────────────
        font_head  = pygame.font.SysFont('Georgia', 26, bold=True)
        font_sec   = pygame.font.SysFont('Arial',   13, bold=True)
        font_entry = pygame.font.SysFont('Arial',   13)
        font_close = pygame.font.SysFont('Arial',   12, italic=True)

        title_surf = font_head.render('— CONTROLS & STATS —', True, (230, 195, 80))
        surface.blit(title_surf, title_surf.get_rect(centerx=W//2, top=PAD+10))

        # ── Two-column layout ─────────────────────────────────────────────────
        COL_L = PAD + 30          # left column x
        COL_R = W // 2 + 20       # right column x
        Y_START = PAD + 52
        LINE_H  = 18
        SEC_H   = 10              # extra gap before a section header

        KEY_COL   = (200, 175, 100)   # key name colour
        DESC_COL  = (200, 195, 185)   # description colour
        SEC_COL   = (120, 200, 140)   # section header colour
        VAL_COL   = (255, 210, 60)    # stat value colour

        def draw_section(surface, x, y, title):
            s = font_sec.render(title, True, SEC_COL)
            surface.blit(s, (x, y))
            pygame.draw.line(surface, (80, 120, 80),
                             (x, y + s.get_height() + 1),
                             (x + 220, y + s.get_height() + 1), 1)
            return y + s.get_height() + 5

        def draw_entry(surface, x, y, key, desc):
            k = font_entry.render(key, True, KEY_COL)
            d = font_entry.render(desc, True, DESC_COL)
            surface.blit(k, (x, y))
            surface.blit(d, (x + 100, y))
            return y + LINE_H

        def draw_stat(surface, x, y, label, value):
            l = font_entry.render(label, True, DESC_COL)
            v = font_entry.render(str(value), True, VAL_COL)
            surface.blit(l, (x, y))
            surface.blit(v, (x + 160, y))
            return y + LINE_H

        # ── LEFT COLUMN: Controls ─────────────────────────────────────────────
        y = Y_START

        y = draw_section(surface, COL_L, y, 'MOVEMENT')
        y = draw_entry(surface, COL_L, y, 'WASD / Arrows', 'Move')
        y += SEC_H

        y = draw_section(surface, COL_L, y, 'COMBAT')
        y = draw_entry(surface, COL_L, y, 'Space / Z',   'Attack (hold to fire)')
        y = draw_entry(surface, COL_L, y, 'Left Alt',    'Roll-Dodge  (1.5 s cd)')
        y = draw_entry(surface, COL_L, y, 'B',           'Plant Bomb')
        y += SEC_H

        y = draw_section(surface, COL_L, y, 'WEAPONS')
        y = draw_entry(surface, COL_L, y, 'Q',           'Cycle to next weapon')
        y = draw_entry(surface, COL_L, y, '1 – 5',       'Equip weapon by slot')
        y += SEC_H

        y = draw_section(surface, COL_L, y, 'INTERACTION')
        y = draw_entry(surface, COL_L, y, 'E',           'Talk / Buy / Open chest')
        y = draw_entry(surface, COL_L, y, 'E (at wall)', 'Use Mystery Key on door')
        y += SEC_H

        y = draw_section(surface, COL_L, y, 'MENUS')
        y = draw_entry(surface, COL_L, y, 'Tab',         'Show / hide controls')
        y = draw_entry(surface, COL_L, y, 'ESC',         'Close menu / Quit')
        y = draw_entry(surface, COL_L, y, 'R',           'Restart (game over only)')
        y += SEC_H

        y = draw_section(surface, COL_L, y, 'TIPS')
        y = draw_entry(surface, COL_L, y, 'Roll',        'Grants coin magnet!')
        y = draw_entry(surface, COL_L, y, 'Bomb a wall', 'Might reveal a secret…')

        # ── RIGHT COLUMN: Stats ───────────────────────────────────────────────
        y = Y_START
        p = self.player

        y = draw_section(surface, COL_R, y, 'PLAYER STATS')
        y = draw_stat(surface, COL_R, y, 'Hearts',
                      f'{p.hearts} / {p.max_hearts}')
        y = draw_stat(surface, COL_R, y, 'Coins',        p.coins)
        y = draw_stat(surface, COL_R, y, 'Armor',
                      f'Tier {p.armor}' if p.armor > 0 else 'None')
        y = draw_stat(surface, COL_R, y, 'Bombs',        p.bombs)
        y = draw_stat(surface, COL_R, y, 'Chest Keys',   p.chest_keys)
        y = draw_stat(surface, COL_R, y, 'Mystery Keys',
                      getattr(p, 'mystery_keys', 0))
        y += SEC_H

        y = draw_section(surface, COL_R, y, 'WEAPONS OWNED')
        from player import WEAPON_ORDER
        from settings import WEAPON_DISPLAY_NAMES, WEAPON_DAMAGE
        for wkey in WEAPON_ORDER:
            if wkey in p.inventory:
                dmg   = WEAPON_DAMAGE.get(wkey, '?')
                name  = WEAPON_DISPLAY_NAMES.get(wkey, wkey.title())
                tag   = ' ◀ equipped' if p.weapon == wkey else ''
                col   = (255, 210, 60) if p.weapon == wkey else DESC_COL
                line  = font_entry.render(f'{name}  (dmg {dmg}){tag}', True, col)
                surface.blit(line, (COL_R, y))
                y += LINE_H
        y += SEC_H

        y = draw_section(surface, COL_R, y, 'WEAPON DAMAGE TABLE')
        for wkey in WEAPON_ORDER:
            name  = WEAPON_DISPLAY_NAMES.get(wkey, wkey.title())
            dmg   = WEAPON_DAMAGE.get(wkey, '?')
            owned = wkey in p.inventory
            col   = (160, 155, 145) if not owned else DESC_COL
            line  = font_entry.render(f'{name:<18} {dmg} dmg', True, col)
            surface.blit(line, (COL_R, y))
            y += LINE_H

        # ── Close hint ────────────────────────────────────────────────────────
        close_surf = font_close.render('Press  TAB  or  ESC  to close', True, (130, 120, 100))
        surface.blit(close_surf, close_surf.get_rect(centerx=W//2, bottom=H - PAD - 6))

    def _draw_main_menu(self):
        """Atmospheric title screen drawn when state == 'main_menu'."""
        W, H = WINDOW_WIDTH, WINDOW_HEIGHT
        cx   = W // 2

        # ── Dark stone background ─────────────────────────────────────────────
        self.screen.fill((8, 6, 5))

        # Stone block texture — draw a subtle grid of slightly lighter tiles
        BLOCK = 40
        for gy in range(0, H, BLOCK):
            for gx in range(0, W, BLOCK):
                shade = 12 if ((gx // BLOCK + gy // BLOCK) % 2 == 0) else 9
                pygame.draw.rect(self.screen, (shade, shade - 2, shade - 3),
                                 (gx, gy, BLOCK - 1, BLOCK - 1))

        # ── Torch glow decorations (left and right of title) ──────────────────
        for tx in (cx - 180, cx + 180):
            ty = H // 2 - 80
            # Warm glow circle (additive-style via alpha surface)
            glow = pygame.Surface((80, 80), pygame.SRCALPHA)
            for r in range(40, 0, -4):
                alpha = max(0, 60 - (40 - r) * 3)
                pygame.draw.circle(glow, (255, 160, 40, alpha), (40, 40), r)
            self.screen.blit(glow, (tx - 40, ty - 40))
            # Torch pole
            pygame.draw.rect(self.screen, (90, 60, 25), (tx - 3, ty + 8, 6, 22))
            # Flame (animated using math.sin)
            t = pygame.time.get_ticks() / 300.0
            for i in range(3):
                fx = tx + int(math.sin(t + i * 1.2) * 3)
                fy = ty - i * 4
                fc = [(255, 200, 50), (255, 130, 20), (220, 60, 10)][i]
                pygame.draw.circle(self.screen, fc, (fx, fy), 5 - i)

        # ── Border frame ──────────────────────────────────────────────────────
        BORD = 18
        pygame.draw.rect(self.screen, (90, 68, 38),
                         (BORD, BORD, W - 2 * BORD, H - 2 * BORD), 3)
        pygame.draw.rect(self.screen, (55, 40, 20),
                         (BORD + 4, BORD + 4, W - 2 * (BORD + 4), H - 2 * (BORD + 4)), 1)

        # ── Sub-title line above main title ───────────────────────────────────
        sub_font = pygame.font.SysFont('Georgia', 16, italic=True)
        sub = sub_font.render('A  DUNGEON  ADVENTURE', True, (160, 130, 75))
        self.screen.blit(sub, sub.get_rect(centerx=cx, bottom=H // 2 - 58))

        # ── Main title: "THE DARK KEEP" ───────────────────────────────────────
        title_font = pygame.font.SysFont('Georgia', 72, bold=True)
        # Drop shadow
        sh = title_font.render('THE DARK KEEP', True, (20, 12, 8))
        self.screen.blit(sh, sh.get_rect(centerx=cx + 3, centery=H // 2 - 20 + 3))
        # Main text in amber-gold gradient (two passes: dark base + bright top)
        t1 = title_font.render('THE DARK KEEP', True, (180, 110, 10))
        t2 = title_font.render('THE DARK KEEP', True, (255, 195, 55))
        self.screen.blit(t1, t1.get_rect(centerx=cx, centery=H // 2 - 20))
        # Clip the bright overlay to upper half of the text for a gradient look
        t2_rect = t2.get_rect(centerx=cx, centery=H // 2 - 20)
        clip    = pygame.Rect(t2_rect.left, t2_rect.top,
                              t2_rect.width, t2_rect.height // 2)
        self.screen.set_clip(clip)
        self.screen.blit(t2, t2_rect)
        self.screen.set_clip(None)

        # ── Wizard sprite (scaled up 2×) ──────────────────────────────────────
        wiz_img = self.player.images.get('down')
        if wiz_img:
            big = pygame.transform.scale(wiz_img,
                  (wiz_img.get_width() * 2, wiz_img.get_height() * 2))
            self.screen.blit(big, big.get_rect(centerx=cx, top=H // 2 + 28))

        # ── "Press ENTER" blinking prompt ─────────────────────────────────────
        if self._menu_blink_on:
            prompt_font = pygame.font.SysFont('Arial', 22, bold=True)
            prompt = prompt_font.render('PRESS  ENTER  TO  BEGIN', True, (220, 200, 120))
            self.screen.blit(prompt, prompt.get_rect(centerx=cx, bottom=H - 50))

        # ── Controls hint (small, bottom) ─────────────────────────────────────
        hint_font = pygame.font.SysFont('Arial', 13)
        hint = hint_font.render('WASD/Arrows: Move   Space/Z: Attack   Q/1-5: Weapons   E: Shop',
                                True, (90, 80, 65))
        self.screen.blit(hint, hint.get_rect(centerx=cx, bottom=H - 26))
