"""
bombs.py — Bomb item for The Dark Keep.

Bombs are awarded by the Quiz Master.  Press B to place one at the
player's position.  After a 3-second fuse the bomb explodes in a large
blast radius that damages both enemies and the player.

Visual cues
-----------
  • Semi-transparent radius ring drawn around the bomb while it ticks.
  • Ring pulses faster and turns red in the final second.
  • Countdown digit (3 → 2 → 1) drawn on the bomb body.
  • On explosion: expanding orange fireball that fades out.
"""

import pygame
import math

from settings import TILE_SIZE

BOMB_RADIUS    = int(3.5 * TILE_SIZE)   # explosion radius in pixels (≈140 px)
BOMB_DAMAGE    = 20                      # HP removed from enemies / player
BOMB_FUSE      = 180                    # frames until explosion (3 s @ 60 fps)
EXPLOSION_TIME = 40                     # frames the fireball flash is shown


class Bomb:
    """
    A placed bomb.

    Attributes
    ----------
    x, y         : int  — world-space centre of the bomb
    exploded     : bool — True once the fuse has run out and explosion applied
    done         : bool — True when the explosion animation is fully finished
    """

    BODY_R = 11    # visual radius of the bomb body (pixel circle)

    def __init__(self, x, y):
        self.x           = x
        self.y           = y
        self.fuse        = BOMB_FUSE
        self.exploded    = False
        self.done        = False
        self._expl_timer = 0

        pygame.font.init()
        self._font = pygame.font.SysFont('Arial', 13, bold=True)

    # ── properties ────────────────────────────────────────────────────────────

    @property
    def countdown(self):
        """Visible countdown: 3 → 2 → 1.  Reaches 0 on explosion frame."""
        return max(0, math.ceil(self.fuse / 60))

    @property
    def blast_rect(self):
        """Pygame Rect that approximates the blast zone (for hit-testing)."""
        return pygame.Rect(self.x - BOMB_RADIUS, self.y - BOMB_RADIUS,
                           BOMB_RADIUS * 2, BOMB_RADIUS * 2)

    def in_blast(self, hitbox):
        """Return True if hitbox centre is within BOMB_RADIUS of the bomb."""
        cx, cy = hitbox.center
        return math.hypot(cx - self.x, cy - self.y) <= BOMB_RADIUS

    # ── update ────────────────────────────────────────────────────────────────

    def update(self):
        """
        Tick the fuse / explosion animation.
        Returns True on the single frame the explosion is triggered so that
        game.py can apply damage exactly once.
        """
        if self.exploded:
            self._expl_timer -= 1
            if self._expl_timer <= 0:
                self.done = True
            return False

        self.fuse -= 1
        if self.fuse <= 0:
            self.exploded    = True
            self._expl_timer = EXPLOSION_TIME
            return True      # ← explosion frame: apply damage now

        return False

    # ── draw ──────────────────────────────────────────────────────────────────

    def draw(self, surface):
        if self.done:
            return

        if self.exploded:
            self._draw_explosion(surface)
            return

        self._draw_radius_ring(surface)
        self._draw_bomb_body(surface)

    # ── private draw helpers ──────────────────────────────────────────────────

    def _draw_radius_ring(self, surface):
        """Semi-transparent circle showing the blast zone."""
        r = BOMB_RADIUS
        ring = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)

        # Pulse alpha based on fuse time; turn red in last second
        pulse = abs(math.sin(self.fuse * 0.18))
        base_alpha = int(25 + 20 * pulse)
        ring_alpha = int(80 + 40 * pulse)

        if self.fuse <= 60:          # last second → red
            fill_col = (255, 60,  40, base_alpha)
            edge_col = (255, 60,  40, ring_alpha)
        else:
            fill_col = (220, 175, 50, base_alpha)
            edge_col = (220, 175, 50, ring_alpha)

        pygame.draw.circle(ring, fill_col, (r, r), r)
        pygame.draw.circle(ring, edge_col, (r, r), r, 2)
        surface.blit(ring, (self.x - r, self.y - r))

    def _draw_bomb_body(self, surface):
        """Dark sphere with a pulsing fuse spark and countdown digit."""
        bx, by = self.x, self.y

        # Outer glow ring
        pygame.draw.circle(surface, (50, 50, 50), (bx, by), self.BODY_R + 2)
        # Body
        pygame.draw.circle(surface, (22, 22, 22), (bx, by), self.BODY_R)
        # Highlight
        pygame.draw.circle(surface, (65, 65, 65), (bx - 3, by - 3), 4)

        # Fuse cord (grey line up-right)
        fx = bx + self.BODY_R - 2
        fy = by - self.BODY_R + 2
        pygame.draw.line(surface, (140, 120, 80), (fx, fy), (fx + 5, fy - 5), 2)

        # Spark — flashes faster as fuse runs low
        flash_rate = 3 if self.fuse > 60 else 2
        if (self.fuse // flash_rate) % 2 == 0:
            spark_col = (255, 210, 50) if self.fuse % 4 < 2 else (255, 110, 20)
            pygame.draw.circle(surface, spark_col, (fx + 6, fy - 6), 4)

        # Countdown digit
        n   = str(self.countdown)
        txt = self._font.render(n, True, (220, 220, 220))
        surface.blit(txt, (bx - txt.get_width() // 2, by - txt.get_height() // 2))

    def _draw_explosion(self, surface):
        """Expanding, fading orange-red fireball."""
        t     = EXPLOSION_TIME - self._expl_timer        # 0 → EXPLOSION_TIME
        frac  = t / EXPLOSION_TIME
        r     = max(4, int(BOMB_RADIUS * frac))
        alpha = max(0, int(230 * (1 - frac)))

        expl = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
        cx = cy = r + 2
        # Outer ring
        pygame.draw.circle(expl, (255, 80, 10, alpha),          (cx, cy), r)
        # Inner bright core (fades faster)
        inner_alpha = max(0, int(alpha * (1 - frac)))
        inner_r     = max(2, r // 2)
        pygame.draw.circle(expl, (255, 230, 80, inner_alpha),   (cx, cy), inner_r)
        surface.blit(expl, (self.x - r - 2, self.y - r - 2))
